<?php 

/**
* This is footer sidebar number three. Registered custom sidebar.
* @link https://developer.wordpress.org/themes/functionality/sidebars/
* @package Really Blog
* @since 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

	if (is_active_sidebar('dt_footer_w_3')) {
		dynamic_sidebar('dt_footer_w_3');
	}


 ?>