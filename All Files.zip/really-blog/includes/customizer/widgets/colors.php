<?php 

/**
 * Here is all the settings, section, controls of Sidebars & Footer Widgets colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function cm_sd_widget_colors( $wp_customize ){

		// Set a field value for sidebar widgets titles color
		$wp_customize->add_setting( 'cm_wid_title_color', [

			'default'				=>		'#444444',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for sidebar widgets anchors color
		$wp_customize->add_setting( 'cm_wid_a_color', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for sidebar widgets paragraph color
		$wp_customize->add_setting( 'cm_wid_p_color', [

			'default'				=>		'#666666',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for footer widgets titles color
		$wp_customize->add_setting( 'cm_fwid_t_color', [

			'default'				=>		'#ffffff',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for footer widgets anchors color
		$wp_customize->add_setting( 'cm_fwid_a_color', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for footer widgets paragraph color
		$wp_customize->add_setting( 'cm_fwid_p_color', [

			'default'				=>		'#666666',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Add a section for widget
		$wp_customize->add_section( 'cm_widget_section', [

			'title'		=>		esc_html__( 'Widget', 'really-blog' ),
			'priority'	=>		30,
			'panel'		=>		'dt_customizer_panel'

		]);

		// Add a field for sidebar widgets titles color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_wid_title_color_set',
			array(

				'label'		=>		esc_html__( 'Title Color', 'really-blog' ),
				'settings'	=>		'cm_wid_title_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

		// Add a field for sidebar widgets anchors color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_wid_a_color_set',
			array(

				'label'		=>		esc_html__( 'Anchor Color', 'really-blog' ),
				'settings'	=>		'cm_wid_a_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

		// Add a field for sidebar widgets text color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_wid_p_color_set',
			array(

				'label'		=>		esc_html__( 'Text Color', 'really-blog' ),
				'settings'	=>		'cm_wid_p_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

		// Add a field for footer widgets titles color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_fwid_t_color_set',
			array(

				'label'		=>		esc_html__( 'Footer Widget Title Color', 'really-blog' ),
				'settings'	=>		'cm_fwid_t_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

		// Add a field for footer widgets anchors color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_fwid_a_color_set',
			array(

				'label'		=>		esc_html__( 'Footer Widget Anchor Color', 'really-blog' ),
				'settings'	=>		'cm_fwid_a_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

		// Add a field for footer widgets text color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'cm_fwid_p_color_set',
			array(

				'label'		=>		esc_html__( 'Footer Widget Text Color', 'really-blog' ),
				'settings'	=>		'cm_fwid_p_color',
				'section'	=>		'cm_widget_section'

			)

		 ) );

	}

 ?>