<?php

/**
 *This is for require and recommended plugins for theme installations notice. After use install the theme, they will notified with the necessary plugins to install and activate with this. This setup is with TGMP plugin activation plugin. This file is included in functions.php
  *
 * @package     Really Blog
 * @link        http://tgmpluginactivation.com/download/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}

function rblog_plugin_bundles(){
    
        $plugins    =   [
            
            [
                'name'      =>      'Custom Post Type Widgets',
                'slug'      =>      'custom-post-type-widgets',
                'required'  =>      false
            ],
            [
            'name'               => 'Really Blog Settings',
            'slug'               => 'really-blog-settings',
            'source'             => RBLOG_THEME_DIR. 'includes/libs/plugins/really-blog-settings.tar',
            'required'           => true,
            'version'            => '',
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => '',
            'is_callable'        => '',
            
            ]
            
            ];
        
        $config     =   [
            
                'id'            =>      'reallyblog_theme',
                'menu'          =>      'tgmpa-install-plugins',
                'parent-slug'   =>      'themes.php',
                'capability'    =>      'edit_theme_options',
                'has_notices'   =>      true,
                'dismissable'   =>      true
                
            ];
        
        tgmpa( $plugins, $config );
    
}

?>