<?php 

/**
 * This file loads all the css and js files of the theme. This file is attached with 'wp_enqueue_scripts' action hook in functions.php
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/wp_enqueue_scripts/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_enqueue_scripts(){

		$uri 		=		esc_url(get_template_directory_uri()); // Theme directory
		$ver		=		DT_DEV_MODE	? time()	: false; // For version of the files enqueuing for cache purpose

		// Registering Styles
		wp_register_style( 'dt_bootstrap_css', $uri.'/assets/css/bootstrap.css', [], $ver  );
		wp_register_style( 'dt_oswald_css', 'https://fonts.googleapis.com/css?family=Oswald:400,700,300', [], $ver  );
		wp_register_style( 'dt_lato_css', 'https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic', [], $ver  );
		wp_register_style( 'dt_fontawesome_css', $uri.'/assets/fonts/font-awesome/css/font-awesome.min.css', [], $ver  );
		wp_register_style( 'dt_mmenu_all_css', $uri.'/assets/css/jquery.mmenu.all.css', [], $ver  );
		wp_register_style( 'dt_owl_carousel_css', $uri.'/assets/css/owl.carousel.css', [], $ver  );
		wp_register_style( 'dt_owl_progress_css', $uri.'/assets/css/bootstrap-progressbar-3.3.4.min.css', [], $ver  );
		wp_register_style( 'dt_magnific_css', $uri.'/assets/css/magnific-popup.css', [], $ver  );
		wp_register_style( 'dt_audioplayer_css', $uri.'/assets/css/audioplayer.css', [], $ver  );
		wp_register_style( 'dt_theme_header_css', get_stylesheet_uri( 'style.css' ), [], $ver  );

		// Enqueuing Styles
		wp_enqueue_style( 'dt_bootstrap_css'  );
		wp_enqueue_style( 'dt_oswald_css'  );
		wp_enqueue_style( 'dt_lato_css'  );
		wp_enqueue_style( 'dt_fontawesome_css'  );
		wp_enqueue_style( 'dt_mmenu_all_css'  );
		wp_enqueue_style( 'dt_owl_carousel_css'  );
		wp_enqueue_style( 'dt_owl_progress_css'  );
		wp_enqueue_style( 'dt_magnific_css'  );
		wp_enqueue_style( 'dt_audioplayer_css'  );
		wp_enqueue_style( 'dt_theme_header_css'  );


		// Custom Logo Size Customizer Options //
		wp_add_inline_style( 'dt_theme_header_css', 

			'img.custom-logo{ width:' .get_theme_mod('dt_header_logo', '50%'). '; }' 

		);



		// Header bottom hide in a condition if the value is 'yes' mean 'ticked'
		if (get_theme_mod( 'dt_header_btm_border_2', 'yes') == 'yes') {
			wp_add_inline_style( 'dt_theme_header_css', 

			'.header-v1{ border: none !important; }' 

		);
		}
		


		// Customizer Colors Options //
		get_template_part( 'includes/front/customizer-colors' );



		// Registering script
		wp_register_script( 'dt_jquery_js', $uri. '/assets/js/vendor/jquery.min.js', [], $ver, true );
		wp_register_script( 'dt_bootstrap_js', $uri. '/assets/js/vendor/bootstrap.js', [], $ver, true );
		wp_register_script( 'dt_waypoint_js', $uri. '/assets/js/plugins/jquery.waypoints.min.js', [], $ver, true );
		wp_register_script( 'dt_isotop_js', $uri. '/assets/js/plugins/isotope.pkgd.min.js', [], $ver, true );
		wp_register_script( 'dt_isotope_custom_js', $uri. '/assets/js/plugins/custom-isotope.js', [], $ver, true );
		wp_register_script( 'dt_mmenu_js', $uri. '/assets/js/plugins/jquery.mmenu.all.min.js', [], $ver, true );
		wp_register_script( 'dt_mobilemenu_js', $uri. '/assets/js/plugins/mobilemenu.js', [], $ver, true );
		wp_register_script( 'dt_bxslider_js', $uri. '/assets/js/plugins/jquery.bxslider.min.js', [], $ver, true );
		wp_register_script( 'dt_bx_blog_js', $uri. '/assets/js/plugins/bx-blog.js', [], $ver, true );
		wp_register_script( 'dt_owl_carousel_js', $uri. '/assets/js/plugins/owl.carousel.js', [], $ver, true );
		wp_register_script( 'dt_owl_js', $uri. '/assets/js/plugins/owl.js', [], $ver, true );
		wp_register_script( 'dt_responsive_tab_js', $uri. '/assets/js/plugins/responsive-tabs.js', [], $ver, true );
		wp_register_script( 'dt_call_tab_js', $uri. '/assets/js/plugins/call-tabs.js', [], $ver, true );
		wp_register_script( 'dt_progressbar_js', $uri. '/assets/js/plugins/bootstrap-progressbar.min.js', [], $ver, true );
		wp_register_script( 'dt_popup_js', $uri. '/assets/js/plugins/jquery.magnific-popup.min.js', [], $ver, true );
		wp_register_script( 'dt_lightbox_js', $uri. '/assets/js/plugins/lightbox-blog.js', [], $ver, true );
		wp_register_script( 'dt_audioplayer_js', $uri. '/assets/js/plugins/audioplayer.js', [], $ver, true );
		wp_register_script( 'dt_custom_js', $uri. '/assets/js/custom.js', [], $ver, true );
		wp_register_script( 'dt_sticky_kit_js', $uri. '/assets/js/plugins/jquery.sticky-kit.min.js', [], $ver, true );
		wp_register_script( 'dt_sticky_js', $uri. '/assets/js/plugins/sticky.js', [], $ver, true );
		wp_register_script( 'dt_template_js', $uri. '/assets/js/plugins/template.js', [], $ver, true );
		wp_register_script( 'dt_template_team_js', $uri. '/assets/js/plugins/template-team-single.js', [], $ver, true );

		// Enqueuing Scripts
		wp_enqueue_script( 'dt_jquery_js' );
		wp_enqueue_script( 'dt_bootstrap_js' );
		wp_enqueue_script( 'dt_waypoint_js' );
		wp_enqueue_script( 'dt_isotop_js' );
		wp_enqueue_script( 'dt_isotope_custom_js' );
		wp_enqueue_script( 'dt_mmenu_js' );
		wp_enqueue_script( 'dt_mobilemenu_js' );
		wp_enqueue_script( 'dt_bxslider_js' );
		wp_enqueue_script( 'dt_bx_blog_js' );
		wp_enqueue_script( 'dt_owl_carousel_js' );
		wp_enqueue_script( 'dt_owl_js' );
		wp_enqueue_script( 'dt_responsive_tab_js' );
		wp_enqueue_script( 'dt_call_tab_js' );
		wp_enqueue_script( 'dt_progressbar_js' );
		wp_enqueue_script( 'dt_popup_js' );
		wp_enqueue_script( 'dt_lightbox_js' );
		wp_enqueue_script( 'dt_audioplayer_js' );
		wp_enqueue_script( 'dt_custom_js' );
		wp_enqueue_script( 'dt_sticky_kit_js' );
		wp_enqueue_script( 'dt_sticky_js' );
		wp_enqueue_script( 'dt_template_js' );
		wp_enqueue_script( 'dt_template_team_js' );


		



	}

 ?>