<?php  

	/**
 * Here all woocommerce files stored.
  *
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}

remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
add_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 9 );

function woocommerce_output_content_wrapper(){

	echo '<div class="main-content"><div class="container">';
	
}

remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
add_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 19 );

function woocommerce_output_content_wrapper_end(){

	echo '</div></div>';
	
}

?>