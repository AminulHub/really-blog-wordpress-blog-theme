<?php 

	/**
 *This file is for custom sidebars register for Widgets. This file is attached with 'widgets_init' action hook in functions.php
  *
 * @package     Really Blog
 * @link        https://developer.wordpress.org/reference/hooks/widgets_init/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}

	function dt_widgetsdt_widgets(){

		// Registering Sidebar
		register_sidebar([

			'name'				=>		esc_html__( 'Really Blog Sidebar', 'really-blog' ),
			'id'				=>		'dt_right_sbar',
			'description'		=>		esc_html__( 'Add your widgets here', 'really-blog' ),
			'before_widget'		=>		'<div id="%1$s" class="widget %2$s">',
			'after_widget'		=>		'</div>',
			'before_title'		=>		'<h3>',
			'after_title'		=>		'</h3>'

		]);

		// Registering Footer sidebar one
		register_sidebar([

			'name'				=>		__( 'Really Blog Footer Widget One', 'really-blog' ),
			'id'				=>		'dt_footer_w_1',
			'description'		=>		esc_html__( 'Add your widgets here', 'really-blog' ),
			'before_widget'		=>		'<div id="%1$s" class="widget widget-footer %2$s">',
			'after_widget'		=>		'</div>',
			'before_title'		=>		'<h3>',
			'after_title'		=>		'</h3>'

		]);

		// Registering Footer sidebar two
		register_sidebar([

			'name'				=>		esc_html__( 'Really Blog Footer Widget Two', 'really-blog' ),
			'id'				=>		'dt_footer_w_2',
			'description'		=>		esc_html__( 'Add your widgets here', 'really-blog' ),
			'before_widget'		=>		'<div id="%1$s" class="widget %2$s">',
			'after_widget'		=>		'</div>',
			'before_title'		=>		'<h3>',
			'after_title'		=>		'</h3>'

		]);

		// Registering Footer sidebar three
		register_sidebar([

			'name'				=>		esc_html__( 'Really Blog Footer Widget Three', 'really-blog' ),
			'id'				=>		'dt_footer_w_3',
			'description'		=>		esc_html__( 'Add your widgets here', 'really-blog' ),
			'before_widget'		=>		'<div id="%1$s" class="widget %2$s">',
			'after_widget'		=>		'</div>',
			'before_title'		=>		'<h3>',
			'after_title'		=>		'</h3>'

		]);

		// Registering Footer sidebar four
		register_sidebar([

			'name'				=>		esc_html__( 'Really Blog Footer Widget Four', 'really-blog' ),
			'id'				=>		'dt_footer_w_4',
			'description'		=>		esc_html__( 'Add your widgets here', 'really-blog' ),
			'before_widget'		=>		'<div id="%1$s" class="widget %2$s">',
			'after_widget'		=>		'</div>',
			'before_title'		=>		'<h3>',
			'after_title'		=>		'</h3>'

		]);


	}



 ?>