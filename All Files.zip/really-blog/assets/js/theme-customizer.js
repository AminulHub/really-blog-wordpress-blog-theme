$(document).ready(function(){

	// Footer Social Icons Misc
	wp.customize( 'cm_fwid_social_icons', function (value){

		value.bind(function(val){

			if (val) {
				$(".footer-social-icons").show();
			}else{
				$(".footer-social-icons").hide();
			}

		});

	} );

	// Breadcrumbs
	wp.customize( 'dt_header_breadcrumb', function(value){

		value.bind(function(val){

			if (val) {
				$("#subheader").show();
			}else{
				$("#subheader").hide();
			}

		});

	});

	// Header Bottom Shadow border
	wp.customize( 'dt_header_btm_border', function(value){

		value.bind(function(val){

			if (val) {
				$(".header-line").show();
			}else{
				$(".header-line").hide();
			}

		});

	});


	// Top bar
	wp.customize( 'dt_top_bar_show', function (value){

		value.bind( function(val){

			if (val) {

				$(".topbar-1").show();

			}else{
				$(".topbar-1").hide();
			}

		});

	});

	// Top Bar Menu
	wp.customize( 'dt_top_bar_menu', function(value){

		value.bind(function(val){

			if (val) {

				$("#menu-top-bar").show();

			}else{
				$("#menu-top-bar").hide();
			}

		});

	} );

	// Header Search Icon
	wp.customize( 'dt_header_search_icon', function(value){

		value.bind(function(val){

			if (val) {

				$(".btn-search-navi").show();

			}else{
				$(".btn-search-navi").hide();
			}

		});

	} );

	// Footer Menu
	wp.customize( 'dt_footer_menu', function(value){

		value.bind(function(val){

			if (val) {

				$(".copyright-1").show();

			}else{
				$(".copyright-1").hide();
			}

		});

	} );

	// Author Box
	wp.customize( 'dt_author_box_show', function(value){

		value.bind(function(val){

			if (val) {

				$(".author-warp").show();

			}else{
				$(".author-warp").hide();
			}

		});

	} );

	// Related Posts
	wp.customize( 'dt_related_post_show', function(value){

		value.bind(function(val){

			if (val) {

				$(".relate-post").show();

			}else{
				$(".relate-post").hide();
			}

		});

	} );

	// Related Projects
	wp.customize( 'dt_related_post_show', function(value){

		value.bind(function(val){

			if (val) {

				$(".relate-project").show();

			}else{
				$(".relate-project").hide();
			}

		});

	} );

	// Project Launch Button
	wp.customize( 'dt_pro_show', function(value){

		value.bind(function(val){

			if (val) {

				$(".portfolio-feature-content .btn-rounded").show();

			}else{
				$(".portfolio-feature-content .btn-rounded").hide();
			}

		});

	} );

});