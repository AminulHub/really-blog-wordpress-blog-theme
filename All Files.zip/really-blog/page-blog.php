
<?php

get_header();

/**
*This is a custom template for blog Page where all blogs will be shown isotope design. Users can choose templates from wordpress page editor.
* Template Name: Blog
* Template Post Type: page
* @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

?>

<!-- Portfolio Filter Warp -->
<section>
	<div class="container">
		<div class="row" style="margin: 0;">
			<?php 

			$protected	=	get_post();

			if (post_password_required($protected->ID)) {
				echo get_the_password_form();
			}else{

			

			 ?>
			<div class="portfolio-warp">
				<div class="filter-portfolio-warp">
					<div class="projectFilter project-style-1">
						<a href="#" data-filter="*" class="current "><h4>All</h4></a>
						<?php 

						$echo_terms		=		get_terms( [

							'taxonomy'		=>		'category',
							'hide_empty'	=>		true

						] );

						foreach ($echo_terms as $terms) {
							?>
							<a href="#" data-filter=".<?php echo $terms->slug; ?>"><h4><?php echo $terms->name; ?></h4></a>
							<?php
						}

						 ?>
					</div> <!-- End Project Fillter -->
				</div>
				<div class="list-portfolio-warp portfolio-4-col">
					<?php

					global $post;



					$rp_porject_por		=	new WP_Query([


						'post_type'			=>		'post',
						'posts_per_page'	=>		-1

					]);

					if ($rp_porject_por->have_posts()) {
						while ($rp_porject_por->have_posts()) {
							$rp_porject_por->the_post();
							?>

							<div class="element-item <?php $cat_port	=	get_the_terms( get_the_ID(), 'category' ); foreach($cat_port as $cat_ports){echo $cat_ports->slug.' ';}?> ">
								<div class="project-item">
									<div class="project-item-img-container">
										<?php 

													if (has_post_thumbnail()) {
														 the_post_thumbnail( 'medium', ['Class' => 'img-responsive'] );
													}

													 ?>
										<!-- Overlay -->
										<div class="overlay-1 ">
											<a href="<?php the_permalink(); ?>">
												<i class="fa fa-link hover-border-theme "></i>
											</a>

											<a class="single-img-popup" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id() )); ?>"><i class="fa fa-expand hover-border-theme "></i></a>
										</div>
										<!-- /overlay -->
									</div>
									<a href="<?php the_permalink(); ?>" ><h4 class="hover-text-theme"><?php the_title(); ?></h4></a>
									<a href="<?php the_permalink(); ?>" ><h4 style="font-size: 12px !important;" class="hover-text-theme"><?php echo wp_kses_post(get_the_date('j M, Y')); ?></h4></a>

									<p class="soft-grey-text hover-text-theme"><?php the_terms( $post->ID, 'category', '',', ', '' ); ?></p>
									<p class="soft-grey-text hover-text-theme"><?php the_excerpt(); ?></p>
								</div>
							</div>
							<?php
						}

						wp_reset_postdata();
					}
					}
					?>
				</div>
			</div>
		</div>
	</div>
</section>  
<!-- /Portfolio -->

<?php get_footer(); ?>