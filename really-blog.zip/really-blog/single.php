
<?php 

/**
* This is main single post page where the details of a post will be shown. If no other post template not selected or not there, then wordpres will use it to show the details of the single post.
* @link https://developer.wordpress.org/themes/template-files-section/post-template-files/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

get_header(); 


?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" id="dt-logged-in" style="margin: 0;">
			<?php 

			$protected_post	=		get_post();

			$get_post_video	=	get_post_meta(get_the_ID(), 'dt_post_video', true);

			if ( $get_post_video	!==	'video' ) {
				if (post_password_required($protected_post->ID)) {
					echo get_the_password_form();
				}else{

					if (have_posts()) {
						while (have_posts()) {
							the_post();
							?>

							<div class="main-page">
								<div id="single-blog" class="single-blog-warp">
									<div class="item-blog">
										<?php 

										global $post;

										$author_id		=		$post->post_author;
										$author_url		=		esc_url(get_author_posts_url($author_id));

										if (has_post_thumbnail()) {
											?>

											<div class="blog-feature-warp">

												<?php the_post_thumbnail( 'Full', [ 'Class'	=>	'img-responsive' ] ); ?>

											</div>

											<?php
										}

										?>

										<div class="blog-feature-content single-feature-blog">
											<div class="blog-text">
												<h2 class="hover-text-theme title-pd-left"><?php single_post_title(); ?></h2>

											</div>
											<div class="blog-feature-content-inner">
												<div class="blog-data">
													<div class="date-time bg-theme">
														<span class="date"><?php echo wp_kses_post(get_the_date('j')); ?></span>
														<span class="month"><?php echo wp_kses_post(get_the_date('M')); ?></span>
													</div>
													<div class="blog-type">
														<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/Icon/blogType.png" class="img-responsive" alt="Image">
													</div>
												</div>
												<div class="blog-text">
													<?php 

													the_content();

													$default	=		[

														'before'		=>		'<p class="text-center">'.esc_html__('Pages:', 'cmb2theme' ),
														'after'			=>		'</p>'

													];

													wp_link_pages($default);

													?>

												</div>
											</div>
											<div class="blog-footer-2 border-color-theme">
												<ul>
													<li><?php esc_html_e( 'Posted by ', 'cmb2theme' ); ?><a href="<?php echo $author_url; ?>" class="hover-text-theme"><?php the_author(); ?></a></li>
													<li><?php esc_html_e( 'On ', 'cmb2theme' ); ?><a href="<?php the_permalink(); ?>" class="hover-text-theme"><?php the_category(' '); ?></a></li>
												<li><a href="<?php the_permalink(); ?>" class="hover-text-theme"><?php comments_number('0', esc_html__('1 Comment','cmb2theme'), '% '.esc_html__( 'Comments', 'cmb2theme' ) ); ?></a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>

								<ul class="pagination pagination-blog pagination-single-blog">
									<li class="nav-links"><?php previous_post_link('%link', '&laquo;'. esc_html__(' PREVIOUS ARTICLE', 'cmb2theme') ); ?></li>
								<li class="nav-links"><?php next_post_link('%link', esc_html__('NEXT ARTICLE', 'cmb2theme'). '&raquo;' ); ?></li>
								</ul>

								<!-- Author -->
								<?php 

								if (get_theme_mod( 'dt_author_box_show', 'yes' )) {
									?>
									<div class="author-warp">
										<div class="author-avatar-warp">
											<?php echo get_avatar( get_the_author_meta('ID'), '150', '','', ['Class'	=>	'img-responsive'] ); ?>
										</div>
										<div class="author-info">
											<h3>Article Author: <?php the_author(); ?></h3>
											<h5 class="job-author color-theme"><?php

											$meta = get_the_author_meta(  'dt_user_upload', $author_id);

											echo "$meta";


											?></h5>
											<p class="des-author"><?php echo nl2br(get_the_author_meta('description')); ?></p>
										</div>
									</div>
									<?php
								}

								?>

								<!-- /Author -->

								<!-- Relate Post -->
								<?php 

								if (get_theme_mod('dt_related_post_show','yes')) {
									?>
									<div class="relate-post">
										<h3 class="title-inline"><?php esc_html_e( 'Related Posts', 'cmb2theme' ); ?></h3>
										<div class="customNavigation customNavigation-1">
											<a class="btn-1 prev-relate-blog hover-border-theme hover-text-theme"><i class="fa fa-chevron-left"></i></a>
											<a class="btn-1 next-relate-blog hover-border-theme hover-text-theme"><i class="fa fa-chevron-right"></i></a>
										</div><!-- End owl button -->
										<div class="relate-blog-warp">
											<div id="owl-relate-blog" class="owl-carousel owl-theme owl-relate-blog ">
												<?php 

												global $post;

												$rp_query		=	new WP_Query([

													'category__in'		=>		wp_get_post_categories( $post->ID ),
													'posts_per_page'	=>		5,
													'post__not_in'		=>		[$post->ID]


												]);

												if ($rp_query->have_posts()) {
													while ($rp_query->have_posts()) {
														$rp_query->the_post();

														?>
														<div class="item">
															<div class="item-blog-sidebar">
																<div class="blog-feature-warp">
																	<?php 

																	if (has_post_thumbnail()) {
																		?>
																		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(array( '85','85' ) , ['Class'	=>	'img-responsive']) ?></a>

																		<?php
																	}

																	?>

																</div>
																<div class="blog-feature-content">
																	<a href="<?php the_permalink(); ?>"><h4 class="hover-text-theme"><?php the_title(); ?></h4></a>
																	<?php the_excerpt(); ?>
																</div>
															</div>
														</div>
														<?php
													}

													wp_reset_postdata();
												}

												?>
											</div>
										</div>
									</div>
									<?php
								}

								?>

								<!-- /Relate Post -->

								<!-- Comment Area -->
								<?php 

								if (comments_open()  || get_comments_number()) {
									comments_template();
								}

								?>
								<!-- /Comment Area -->
							</div>

							<?php
						}
					}


				}
			}


			if ( $get_post_video	==	'video' ) {
				if (post_password_required($protected_post->ID)) {
					echo get_the_password_form();
				}else{

					if (have_posts()) {
						while (have_posts()) {
							the_post();
							?>

							<div class="main-page">
								<div id="single-blog" class="single-blog-warp">
									<div class="item-blog">
										<?php 

										global $post;

										$author_id		=		$post->post_author;
										$author_url		=		esc_url(get_author_posts_url($author_id));

										?>

										<div class="blog-feature-warp">

											<?php 

											$url = esc_url( get_post_meta( get_the_ID(), 'dt_video_upload', 1 ) );
											echo wp_oembed_get( $url ); 

											?>

										</div>

										<div class="blog-feature-content single-feature-blog">
											<div class="blog-text">
												<h2 class="hover-text-theme title-pd-left"><?php single_post_title(); ?></h2>

											</div>
											<div class="blog-feature-content-inner">
												<div class="blog-data">
													<div class="date-time bg-theme">
														<span class="date"><?php echo wp_kses_post(get_the_date('j')); ?></span>
														<span class="month"><?php echo wp_kses_post(get_the_date('M')); ?></span>
													</div>
													<div class="blog-type">
														<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/Icon/blogType-video.png" class="img-responsive" alt="Image">
													</div>
												</div>
												<div class="blog-text">
													<?php 

													the_content();

													$default	=		[

														'before'		=>		'<p class="text-center">'.esc_html__('Pages:', 'cmb2theme' ),
														'after'			=>		'</p>'

													];

													wp_link_pages($default);

													?>

												</div>
											</div>
											<div class="blog-footer-2 border-color-theme">
												<ul>
													<li><?php esc_html_e( 'Posted by ', 'cmb2theme' ); ?><a href="<?php echo $author_url; ?>" class="hover-text-theme"><?php the_author(); ?></a></li>
													<li><?php esc_html_e( 'On ', 'cmb2theme' ); ?><a href="<?php the_permalink(); ?>" class="hover-text-theme"><?php the_category(' '); ?></a></li>
													<li><a href="<?php the_permalink(); ?>" class="hover-text-theme"><?php comments_number('0', esc_html__('1 Comment','cmb2theme'), '% '.esc_html__( 'Comments', 'cmb2theme' ) ); ?></a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>

								<ul class="pagination pagination-blog pagination-single-blog">
									<li class="nav-links"><?php previous_post_link('%link', '&laquo;'. esc_html__(' PREVIOUS ARTICLE', 'cmb2theme') ); ?></li>
								<li class="nav-links"><?php next_post_link('%link', esc_html__('NEXT ARTICLE', 'cmb2theme'). '&raquo;' ); ?></li>
								</ul>

								<!-- Author -->
								<?php 

								if (get_theme_mod('dt_author_box_show','yes')) {
									?>
									<div class="author-warp">
										<div class="author-avatar-warp">
											<?php echo get_avatar( get_the_author_meta('ID'), '150', '','', ['Class'	=>	'img-responsive'] ); ?>
										</div>
										<div class="author-info">
											<h3><?php esc_html_e( 'Articles Author: ', 'cmb2theme' ); ?><?php the_author(); ?><?php the_author(); ?></h3>
											<h5 class="job-author color-theme">
												<?php

												$meta = get_the_author_meta(  'dt_user_upload', $author_id);

												echo "$meta";


												?></h5>
												<p class="des-author"><?php echo nl2br(get_the_author_meta('description')); ?></p>
											</div>
										</div>
										<?php
									}

									?>

									<!-- /Author -->

									<!-- Relate Post -->
									<?php 

									if (get_theme_mod('dt_related_post_show','yes')) {
										?>
										<div class="relate-post">
											<h3 class="title-inline"><?php esc_html_e( 'Related Posts', 'cmb2theme' ); ?></h3>
											<div class="customNavigation customNavigation-1">
												<a class="btn-1 prev-relate-blog hover-border-theme hover-text-theme"><i class="fa fa-chevron-left"></i></a>
												<a class="btn-1 next-relate-blog hover-border-theme hover-text-theme"><i class="fa fa-chevron-right"></i></a>
											</div><!-- End owl button -->
											<div class="relate-blog-warp">
												<div id="owl-relate-blog" class="owl-carousel owl-theme owl-relate-blog ">
													<?php 

													global $post;

													$rp_query		=	new WP_Query([

														'category__in'		=>		wp_get_post_categories( $post->ID ),
														'posts_per_page'	=>		5,
														'post__not_in'		=>		[$post->ID]


													]);

													if ($rp_query->have_posts()) {
														while ($rp_query->have_posts()) {
															$rp_query->the_post();

															?>
															<div class="item">
																<div class="item-blog-sidebar">
																	<div class="blog-feature-warp">
																		<?php 

																		if (has_post_thumbnail()) {
																			?>
																			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(array( '85','85' ) , ['Class'	=>	'img-responsive']) ?></a>

																			<?php
																		}

																		?>

																	</div>
																	<div class="blog-feature-content">
																		<a href="<?php the_permalink(); ?>"><h4 class="hover-text-theme"><?php the_title(); ?></h4></a>
																		<?php the_excerpt(); ?>
																	</div>
																</div>
															</div>
															<?php
														}

														wp_reset_postdata();
													}

													?>
												</div>
											</div>
										</div>
										<?php
									}

									?>

									<!-- /Relate Post -->

									<!-- Comment Area -->
									<?php 

									if (comments_open()  || get_comments_number()) {
										comments_template();
									}

									?>
									<!-- /Comment Area -->
								</div>

								<?php
							}
						}


					}
				}



				?>

				<!-- /Main Page -->

			</div>
			<div class="sidebar-page">
				<?php get_sidebar(); ?>
			</div>
		</div>
	</section>
	<!-- /Main Content -->

	<?php get_footer(); ?>