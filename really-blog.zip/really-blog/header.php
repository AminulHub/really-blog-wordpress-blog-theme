
<?php 

/**
* This is the default or main header for all templates. Use get_header() in any other templates to show this.
* @link https://developer.wordpress.org/themes/functionality/custom-headers/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

 ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>


<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<!-- Bootstrap CSS -->

	<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>

	<?php wp_body_open(); ?>

	<div id="page">

		

		
		<!-- topbar -->
		<?php 

		if (get_theme_mod( 'dt_top_bar_show', 'yes') ) {
			?>
			<div class="topbar-1 bg-theme">
				<div class="topbar-1-inner ">

					<?php 

					if ( get_theme_mod('dt_top_bar_menu', 'yes' )) {
						if (has_nav_menu('secondary')) {
							wp_nav_menu([

								'theme_location'		=>		'secondary',
								'menu_class'			=>		'subnavi',
								'container'				=>		false,
								'fallback_cb'			=>		false,
								'depth'					=>		1,

							]);
						}else{
							wp_nav_menu([

								'theme_location'		=>		'secondary',
								'menu_class'			=>		'subnavi',
								'container'				=>		false,
								'fallback_cb'			=>		'wpex_default_top_menu',
								'depth'					=>		1,

							]);
						}
					}



					?>

					<ul class="social social-1">
						<?php 

						if (get_theme_mod( 'dt_top_fb_handle', 'your_handle' )) {
							?>

							<li><a href="https://facebook.com/<?php echo esc_url(get_theme_mod('dt_top_fb_handle')); ?>" class="color-theme hover-text-dark"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>

							<?php
						}

						?>
						<?php 

						if (get_theme_mod('dt_top_twitter_handle', 'your_handle')) {
							?>
							<li><a href="https://twitter.com/<?php echo esc_url(get_theme_mod('dt_top_twitter_handle')); ?>" class="color-theme hover-text-dark"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<?php
						}

						?>
						<?php 

						if (get_theme_mod('dt_top_insta_handle', 'your_handle')) {
							?>
							<li><a href="https://instagram.com/<?php echo esc_url(get_theme_mod('dt_top_insta_handle')); ?>" class="color-theme hover-text-dark"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<?php
						}

						?>
						<?php 

						if (get_theme_mod('dt_top_tumb_handle', 'your_handle')) {
							?>
							<li><a href="https://tumblr.com/<?php echo esc_url(get_theme_mod('dt_top_tumb_handle')); ?>" class="color-theme hover-text-dark"><i class="fa fa-tumblr" aria-hidden="true"></i></a></li>
							<?php
						}

						?>
						<?php 

						if (get_theme_mod('dt_top_gplus_handle', 'your_handle')) {
							?>
							<li><a href="https://linkedin.com/<?php echo esc_url(get_theme_mod('dt_top_gplus_handle')); ?>" class="color-theme hover-text-dark"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
							<?php
						}

						?>
					</ul>

					<ul class="topbar-info topbar-info-1">
						<?php 

						if (get_theme_mod( 'dt_top_email', 'info@example.com' )) {
							?>
							<li><span><?php esc_html_e( 'Email: ', 'really-blog' ); ?></span>&nbsp;&nbsp;<a href="mailto:<?php echo esc_url(get_theme_mod('dt_top_email')); ?>"><?php echo esc_html(get_theme_mod('dt_top_email', 'info@example.com')); ?></a></li>
							<?php
						}

						?>
						<?php 

						if (get_theme_mod('dt_top_p_number', '312 88 098')) {
							?>
							<li><span><?php esc_html_e( 'Phone: ', 'really-blog' ); ?></span>&nbsp;&nbsp;<a href="tel:<?php echo esc_url(get_theme_mod('dt_top_p_number')); ?>"><?php echo esc_html(get_theme_mod('dt_top_p_number', '312 88 098')); ?></a></li>
							<?php
						}

						?>
					</ul>
				</div>
			</div>
			<?php
		}

		?>
		
		<!-- /topbar -->
		<?php 

		if (get_theme_mod( 'dt_header_sticked', 'yes' ) == 'yes') {
			?>
			<style type="text/css">
				.header-v1.is_stuck{

					display: none !important;

				}
			</style>
			<?php
		}


		?>


		

		<!-- Header -->
		<header id="stick" class="header-v1">
			<div class="header-v1-inner">
				<div class="logo-1">
					<?php 

					if (has_custom_logo()) {
						?>

						<a href="<?php echo esc_url(home_url('/')); ?>"><?php the_custom_logo(); ?></a>
						<?php 

					}else{

						?>

						<h2 style="font-size:30px; margin-bottom: 0;"><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></h2>
						<?php 

						if (get_theme_mod( 'dt_header_tagline_showed','yes' )) {
							?>
							<p class="slogan-1"><?php bloginfo('description'); ?></p>
							<?php
						}

						?>
						<?php

					}

					?>


				</div>
				<ul class="navi-right">
					
					<li>
						<?php 

						if (get_theme_mod('dt_header_search_icon','yes')) {
							?>

							<a href="#" class="btn-search-navi"><i class="fa fa-search " aria-hidden="true"></i></a>

							
							
							<div class="search-popup">
								<form class="form-search-navi search-form" method="get" action="<?php echo esc_url(home_url('/')); ?>">
									<div class="input-group">
										<input name="s" value="<?php esc_attr(the_search_query()); ?>" class="form-control" placeholder="<?php esc_attr_e( 'Search Here', 'really-blog' ); ?>" type="search">
									</div>
									<!-- /input-group -->
								</form>
							</div>
						</li>
						<?php
					}

					?>
				</ul>
				<?php 

				if (has_nav_menu('primary')) {
					wp_nav_menu([

						'theme_location'		=>		'primary',
						'menu_class'			=>		'navi-level-1',
						'container'				=>		'nav',
						'container_class'		=>		'nav-r',
						'container_id'			=>		'main-navi',
						'fallback_cb'			=>		false,
						'depth'					=>		4,
						'walker'				=>		new DT_NAV_WALKER()

					]);
				}else{
					wp_nav_menu([

						'theme_location'		=>		'primary',
						'menu_class'			=>		'navi-level-1',
						'container'				=>		'nav',
						'container_class'		=>		'nav-r',
						'container_id'			=>		'main-navi',
						'fallback_cb'			=>		'wpex_default_menu',
						'depth'					=>		4,

					]);
				}

				?>
				<a href="#menu" class="btn-menu-mobile"><i class="fa fa-bars" aria-hidden="true"></i></a>
			</div>
		</header>
		<?php 
		if (get_theme_mod('dt_header_btm_border','yes')) {
			?>
			<div class="header-line"></div>
			<?php
		}
		?>
		
		<!-- /Header -->

		<!-- Subheader -->
		<?php 

		$cat_id 	= get_query_var('cat');
		$cat_id_tag = get_query_var('tag');

		if (get_theme_mod( 'dt_header_breadcrumb', 'yes' )) {
			if (!is_front_page()) {
			?>

			<section id="subheader" class="no-padding sub-header-border">
				<div class="container">
					<div class="row">
						<div class="sub-header-warp">
							<?php 

							if ($cat_id) {
								?>
								<h4 class="title-subheader"><?php the_archive_title(); ?></h4>
								<?php
							}

							?>
							<?php 

							if ($cat_id_tag) {
								?>
								<h4 class="title-subheader"><?php the_archive_title(); ?></h4>
								<?php
							}

							?>
							<?php 

							if (is_author()) {
								?>
								<h4 class="title-subheader"><?php esc_html_e( 'Author Archives', 'really-blog' ); ?></h4>
								<?php
							}

							?>
							<?php 

							if ( is_archive('date' )) {
								?>
								<h4 class="title-subheader"><?php 

								if (is_year()) {
									echo "This is year archive";
								}elseif(is_month()){
									echo "This is month archive";
								}elseif(is_date()){
									echo "This is day archive";
								}

								?></h4>

								<?php
							}

							?>
							<?php 

							if (is_attachment()) {
								?>
								<h4 class="title-subheader"><?php esc_html_e( 'Attachment Page', 'really-blog' ); ?></h4>
								<?php
							}

							?>
							<?php 

							if (!is_attachment()) {
								?>
								<h3 class="title-subheader"><?php single_post_title(); ?></h3>
								<?php
							}

							?>
							<ol class="breadcrumb">
								<li><?php esc_html_e( 'You are here: ', 'really-blog' ); ?></li>
								<li>
									<a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e( 'Home', 'really-blog' ); ?></a>
								</li>

								<li class="active"><?php single_post_title(); ?></li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<?php
		}

		}

		
		?>

		<?php 

		if ( get_theme_mod( 'dt_header_mbl_search_box', 'yes' ) ) {
			?>
		<section class="widget_search header-res-search-box">
			<?php echo get_search_form(); ?>
		</section>
			
			<?php
		}

		 ?>

		

			   	<!-- /Subheader -->