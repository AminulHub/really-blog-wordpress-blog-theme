<?php 

/**
* This is for Custom Post Type 'Team' single page contact form mail function configuration file. So that users message can be sent to the members through that contac form to the member email address
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // exit if accessed directly
}

if(isset($_POST['submit'])){
    $to = get_post_meta( get_the_ID(), 'dt_to_mail', true ); // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $first_name = $_POST['name'];
    $subject = "Message From";
    $message = $first_name . " " . " wrote the following:" . "\n\n" . $_POST['message'];

    $headers = "From:" . $from;
    mail($to,$subject,$message,$headers);
    echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }

 ?>