<?php 

/**
*This is the main footer for every posts, pages. Use get_footer() anywhere in other templates to show this template.
* @link https://developer.wordpress.org/reference/functions/get_footer/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

 ?>
			   	<!-- Footer -->
			   	<footer class="footer-v1">
			   		<div class="container">	
			   			<div class="row">
			   				<!-- Footer Widgets -->
			   				<div class="col-md-3">
			   					<?php get_sidebar( 'footer-one' ); ?> 
			   				</div>
			   				<div class="col-md-3">
			   					<?php get_sidebar( 'footer-two' ); ?>
			   				</div>
			   				<div class="col-md-3">
			   					<?php get_sidebar( 'footer-three' ); ?>
			   				</div>
			   				<div class="col-md-3">
			   					<?php get_sidebar( 'footer-four' ); ?>
			   				</div>
			   			</div>
			   		</div>
			   	</footer>
			   	<!-- /Footer -->
			   	<section class="no-padding" id="copyright-1">
			   		<div class="container">
			   			<div class="row" style="margin: 0;">
			   				<div class="warp-copyright-1">
			   					<?php 

			   					// Checking if the footer menu to show. Default will be shown
			   					if (get_theme_mod( 'dt_footer_menu', 'yes' )) {
			   						if (has_nav_menu('footer')) {
			   						wp_nav_menu([

			   							'theme_location'	=>	'footer',
			   							'menu_class'		=>	'copyright-1',
			   							'container'			=>	false,
			   							'depth'				=>	1,
			   							'fallback_cb'		=>	false

			   						]);
			   					}else{ // Else default menu is showing if no menu set.
			   						wp_nav_menu([

			   							'theme_location'	=>	'footer',
			   							'menu_class'		=>	'copyright-1',
			   							'container'			=>	false,
			   							'depth'				=>	1,
			   							'fallback_cb'		=>	'wpex_default_fot_menu'

			   						]);
			   					}
			   					}

			   					

			   					 ?>

				   				<p class="text-copyright-1">
				   					<?php 

				   					// Customizer options value for Copyright text
				   					echo wp_kses_post(get_theme_mod( 'dt_footer_copyright', __( '© Copyright 2022. <a href="#">Really Blog</a>. All right reserved.', 'really-blog' ) ) ); 

				   					?>
				   				</p>
			   				</div>
			   			</div>
			   		</div>
			   	</section>
		</div>

		<a id="to-the-top" class="fixbtt"><i class="fa fa-chevron-up"></i></a> 

		<!-- Mobile Menu -->

		<?php

		if (has_nav_menu('primary')) {
			wp_nav_menu([

				'theme_location'		=>		'primary',
				'container'				=>		'nav',
				'container_id'			=>		'menu',
				'fallback_cb'			=>		false,
				'depth'					=>		4,

			]);
		}

		?>

		<!-- /Mobile Menu -->
		<!-- Back To Top -->

		<!-- SCRIPT -->

	    <script src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/vendor/jquery.min.js"></script>
	    

	    <?php wp_footer(); ?>
	</body>



</html>