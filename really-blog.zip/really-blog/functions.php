<?php 

/**
* This is theme setup and functions file.
* @link https://developer.wordpress.org/themes/basics/theme-functions/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // exit if accessed directly
}



// Setup //
define('DT_DEV_MODE', false); // Using this constant in enqueue file. This constant is for cache purpose on Development mode. If we set the value to 'false' then the browser cache will work where this constant is being used as of their versions.



// Includes //
include( get_theme_file_path( '/includes/front/enqueue.php' ) ); // Main enqueue file of Js & Css files of 'wp_enqueue_scripts' hook
include( get_theme_file_path( '/includes/setup.php' ) ); // Setup file of the theme of 'after_setup_theme' hook
include( get_theme_file_path( '/includes/custom-nav-walker.php' ) ); // Custom nave walker file congiguration for sub menus
include( get_theme_file_path( '/includes/widgets.php' ) ); // Sidebar & Widget registering file of 'widgets_init' hook
include( get_theme_file_path( '/includes/customizer/theme-customizer.php' ) ); // Main customizer options registering file of 'customize_register' hook
include( get_theme_file_path( '/includes/customizer/header/top-bar-info.php' ) ); // Top Bar Customizer options settings
include( get_theme_file_path( '/includes/customizer/header/misc.php' ) ); // Header Misc Customizer options settings
include( get_theme_file_path( '/includes/customizer/header/colors.php' ) ); // Header colors customizer options settings
include( get_theme_file_path( '/includes/customizer/footer/misc.php' ) ); // Footer Misc customizer options settings
include( get_theme_file_path( '/includes/customizer/footer/colors.php' ) ); // Footer colors customizer options settings
include( get_theme_file_path( '/includes/customizer/global/colors.php' ) ); // Global colors customizer options settings
include( get_theme_file_path( '/includes/customizer/blog/color.php' ) ); // Single blog page colors customizer options settings
include( get_theme_file_path( '/includes/customizer/widgets/colors.php' ) ); // Sidebar & Footer widgets colors customizer options settings
include( get_theme_file_path( '/includes/customizer/widgets/misc.php' ) ); // Sidebar & Footer widgets misc customizer options settings
include( get_theme_file_path( '/includes/customizer/author-box/author-box.php' ) ); // Author box misc customizer options settings
include( get_theme_file_path( '/includes/customizer/author-box/colors.php' ) ); // Author box colors customizer options settings
include( get_theme_file_path( '/includes/customizer/related-posts/related-posts.php' ) ); // Related posts & projects misc customizer options settings
include( get_theme_file_path( '/includes/customizer/related-posts/colors.php' ) ); // Related posts & projects colors customizer options settings
include( get_theme_file_path( '/includes/customizer/preview-init.php' ) ); // To override default customzer preview settings of hook 'customize_preview_init'
include( get_theme_file_path( '/includes/customizer/project/project.php' ) ); // Projects single page misc customizer options settings
include( get_theme_file_path( '/includes/customizer/project/colors.php' ) ); // Projects single page colors customizer options settings
include( get_theme_file_path( '/includes/customizer/team/colors.php' ) ); // Team member single page colors customizer options settings
include( get_theme_file_path( '/includes/customizer/comment/colors.php' ) ); // Comments section colors customizer options settings
include( get_theme_file_path( '/includes/admin/admin-scripts.php' ) ); // To add js & css file for Admin pages of hook 'admin_enqueue_scripts'
include( get_theme_file_path( '/includes/init.php' ) ); // To register custom post type , custom taxonomies etc. with 'init' hook
include( get_theme_file_path( '/includes/plugins-bundle.php' ) ); // Showing notice of require and recommended plugins upon theme installation
include( get_theme_file_path( '/extensions/typography/ctypo.php' ) ); // Custom typgraphy option in the customizer
require_once( get_theme_file_path( 'includes/libs/class-tgm-plugin-activation.php' ) ); // Showing notice of require and recommended plugins upon theme installation. Including 'TGMP' plugin



// Hooks //
add_action( 'wp_enqueue_scripts', 'dt_enqueue_scripts' ); // Hook and function of enqueuing Js & Css files for the theme. Go to 'inlcudes/front/enqueue.php'
add_action( 'after_setup_theme', 'dt_setup_theme' ); // Hook of setup files after theme loads. Go to 'includes/setup.php'
add_action( 'widgets_init', 'dt_widgetsdt_widgets' ); // Hook of registering sidebars & widgets. Go to 'includes/widgets.php'
add_action( 'customize_register', 'dt_customize_api' ); // Hook of registering customizer options. Go to 'includes/customizer/theme-customizer.php'
add_action( 'customize_preview_init', 'dt_customize_preview' ); // Hook of customizer preview to override with js. Go to 'includes/customizer/preview-init.php'
add_action( 'init', 'custom_taxonomy', 0 ); // Hook of registering custom post type & custom taxonomies. Go to 'includes/init.php'
add_action( 'tgmpa_register', 'cmt_plugin_bundles' ); // Hook of plugins bundles notice upon theme installation. Go to 'includes/plugins-bundle.php'
add_action( 'admin_enqueue_scripts', 'dt_admin_files' ); // Hook of enqueuing js & css files for admin pages. Go to 'includes/admin/admin-scripts.php'



//Shortcodes //



// CMB2 //
require_once( 'extensions/cmb2/init.php' ); // To use CMB2 need two files to add here. One is CMB2 'init.php'
require_once( 'extensions/cmb2/config.php' ); // To use CMB2 need two files to add here. One is CMB2 'config.php'
require_once( 'extensions/cmb2-logics/cmb2-conditionals.php' ); // CMB2 Conditional logics configuration file



// Default Menus File // For Main Menu, Top Bar, Footer
require( 'partials/default-menus/default-menus.php' );



// Filtering Title File //
require( 'partials/filters/title-filter.php' );



// Filtering Post Excerpt File //
require( 'partials/filters/excerpt-filter.php' );



// Filter the comment Reply Link Text File //
require( 'partials/filters/comment-reply-link-filter.php' );



// Filter Comment Author URL File //
require( 'partials/filters/comment-author-url-filter.php' );



// Filter Comment Date File //
require( 'partials/filters/comment-date-filter.php' );



// Share Icons File For Posts & Projects //
require( 'partials/filters/share-icons.php' );



// Filtering the excerpt more signs file //
require( 'partials/filters/excerpt-sign-filter.php' );



// Woocommerce File //
require_once( get_template_directory(). '/includes/woocommerce/all.php' );



// Filter Comment Text
// add_filter( 'comment_text', 'customizing_comment_text', 20, 3 );
// function customizing_comment_text( $comment_text, $comment, $args ) {
//     if( $comment->comment_type === 'comment' ) {
//         $comment_text =  $comment_text. '<button id="dt-cmnt-replies">REPLIES</button>';
//     }
//     return $comment_text;
// }




?>