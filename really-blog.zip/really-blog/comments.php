<?php 

/**
*This template is the comments template. It contains both comment form and comments list. It will only visible if any page or post allow comments there. Use comments_template() to show this in any other templates.
* @link https://developer.wordpress.org/themes/template-files-section/partial-and-miscellaneous-template-files/comment-template/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

 ?>



<div class="comment-area">

	<h3 class="title"><?php esc_html_e( 'Comments', 'cmb2theme' ); ?></h3>
	<p class="comment-count"><?php esc_html_e( 'There are ', 'cmb2theme' ); ?> 
	<span>

		<?php comments_number( 
			'0'.esc_html__( ' Comment', 'cmb2theme' ),
			'1'.esc_html__( ' Comment', 'cmb2theme'), 
			'%'.esc_html__( ' Comments', 'cmb2theme' ) 
		);
		?>
			
	</span> 
	<?php esc_html_e( 'on ', 'cmb2theme' ); ?> “<?php the_title(); ?>”</p>

	<div class="comment-list-item">
		<?php 

		// Checking if any comments there.
		if (have_comments()) {

			wp_list_comments(); // Showing the comments list

		}

		 ?>

		

	</div>
	<!-- /end list 1 -->

	<!-- Comment Form -->
	<div class="comment-form-warp">

		<?php 

		comment_form([

			'fields'			=>		[

				'name'			=>		'<div class="left-form-comment"><div class="form-group">
											<input name="author" type="text" class="form-control" id="exampleInputName2" placeholder="'.esc_html__('Your Name...','cmb2theme').'">
										</div>',
				'email'			=>		'<div class="form-group">
											<input name="email" type="email" class="form-control" id="exampleInputEmail2" placeholder="'.esc_html__('Your Email', 'cmb2theme' ).'">
										</div>'

			],
			'submit_button'		=>		'<button id="%2$s" type="submit" class="%3$s ot-btn btn-main-bg btn-rounded bg-theme bg-main-theme-callback text-up white-text" value="%4$s">'.esc_html__('SEND MESSAGE', 'cmb2theme' ).' <i class="fa fa-arrow-circle-right" 		aria-hidden="true"></i></button>',

			'comment_field'		=>		'<div class="right-form-comment">
											<textarea name="comment" id="textarea" class="form-control" rows="7" required="required" placeholder="'.esc_html__('Your Message','cmb2theme').'"></textarea>
										</div>',
			
			'title_reply'		=>		'<h3>'.esc_html__( 'Leave A Comment', 'cmb2theme' ).'</h3>',
			
			'class_form'		=>		'form-inline comment-form',
			'title_reply_to'	=>		esc_html__( 'Leave a Reply to ', 'cmb2theme' ).'%s <br />'

		]);

		 ?>
	</div>
</div>