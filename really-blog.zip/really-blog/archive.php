
<?php 

/**
*This template is for theme default or main  archive page. If no archive template is no there, then wordpress will use this template to show archive things.
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); 

?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" style="margin: 0;">
			<div id="list-blog" class="list-blog-warp">
				<div class="archi-des">
					<?php the_archive_description(); ?>
				</div>
				<?php 



				if (have_posts()) {
					while(have_posts()){
						the_post();			   											   							
						// Getting Post Type Video's video url from custom field
						$get_post_video	=	get_post_meta(get_the_ID(), 'dt_post_video', true);

						// Checking if custom filed post type is not video
						if ( $get_post_video	!==	'video' ) {
							get_template_part( 'partials/posts/content-excerpt' );
						}else{
							get_template_part( 'partials/posts/content-excerpt-video' );
						}
					}

					?>

					<?php 

					// Full pagination with 1,2,3.. signs
					echo get_the_posts_pagination([


						'prev_text'		=>		esc_html__( '< BACK', 'cmb2theme' ),
						'next_text'		=>		esc_html__( 'FORWARD >', 'cmb2theme' ),
						'class'			=>		'pagination-blog'

					]); 

					?>


					<?php
				}

				?>



			</div>


		</div>
	</div>
</section>
<!-- /Main Content -->



<?php get_footer(); ?>