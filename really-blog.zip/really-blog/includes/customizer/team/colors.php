<?php 

/**
 * Here is all the settings, section, controls of Team Single Page colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_team_colors( $wp_customize ){

		// Set a field value for Team memeber page headings
		$wp_customize->add_setting( 'dt_team_titles', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for tema member skills bar
		$wp_customize->add_setting( 'dt_team_bar', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Add a section for Team
		$wp_customize->add_section( 'dt_team_section', [

			'title'			=>		esc_html__( 'Team', 'cmb2theme' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		]);

		// Add a field for team single page headings color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_team_titles_set',
			array(

				'label'		=>		esc_html__( 'Titles Color', 'cmb2theme' ),
				'settings'	=>		'dt_team_titles',
				'section'	=>		'dt_team_section'	

			)

		));

		// Add a field for Team skills bar
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_team_bar_set',
			array(

				'label'		=>		esc_html__( 'Progress Bar Color', 'cmb2theme' ),
				'settings'	=>		'dt_team_bar',
				'section'	=>		'dt_team_section'	

			)

		));

	}

?>