<?php 


/**
 * Here is all the settings, section, controls of Blog single page colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function cm_blog_colors( $wp_customize ){

		// Set a field value Post Date Box Background color
		$wp_customize->add_setting( 'cm_date_box', [

		'default'				=>		'#deb152',
		'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Setting a field value for Date box text color
		$wp_customize->add_setting( 'cm_date_txt_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for Blog Type Icon Background Color
		$wp_customize->add_setting( 'cm_blog_ptype_bg', [

		'default'				=>		'#444444',
		'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Add a section for Blog
		$wp_customize->add_section( 'cm_blog_section', [

			'title'			=>		esc_html__( 'Blog', 'cmb2theme' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		]);

		// Add a field For date box bg color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'cm_date_box_set',
			array(

				'label'		=>		esc_html__( 'Date Box Bg Color', 'cmb2theme' ),
				'settings'	=>		'cm_date_box',
				'section'	=>		'cm_blog_section'

			)

		) );

		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'cm_date_txt_color_set',
			array(

				'label'		=>		esc_html__( 'Date Box Color', 'cmb2theme' ),
				'settings'	=>		'cm_date_txt_color',
				'section'	=>		'cm_blog_section'

			)

		) );

		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'cm_blog_ptype_bg_set',
			array(

				'label'		=>		esc_html__( 'Blog Type Bg Color', 'cmb2theme' ),
				'settings'	=>		'cm_blog_ptype_bg',
				'section'	=>		'cm_blog_section'

			)

		) );

	}

 ?>