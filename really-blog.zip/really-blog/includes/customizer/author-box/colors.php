<?php 


/**
 * Here is all the settings, section, controls of Author Box colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_author_color( $wp_customize ){

	// Setting a field value for Author name color	
	$wp_customize->add_setting( 'dt_author_name', [

		'default'				=>		'#444444',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Setting a field value for author skills color
	$wp_customize->add_setting( 'dt_author_expert', [

		'default'				=>		'#deb152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Setting a field value for author bio description
	$wp_customize->add_setting( 'dt_author_des', [

		'default'				=>		'#666666',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Add a section for Author Box
	$wp_customize->add_section( 'dt_author_section', [

			'title'			=>		esc_html__( 'Author Box', 'really-blog' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

	]);

	// Add a field For Author name color option
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_author_name_set',
		array(  

			'label'		=>		esc_html__( 'Author Name Color', 'really-blog' ),
			'section'	=>		'dt_author_section',
			'settings'	=>		'dt_author_name',
		)
	)

);

	// Add a field for author skills color option
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_author_expert_set',
		array(  

			'label'		=>		esc_html__( 'Author Skills Color', 'really-blog' ),
			'section'	=>		'dt_author_section',
			'settings'	=>		'dt_author_expert',
		)
	)


);

	// Add a field for author bio description
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_author_des_set',
		array(  

			'label'		=>		esc_html__( 'Author Description Color', 'really-blog' ),
			'section'	=>		'dt_author_section',
			'settings'	=>		'dt_author_des',
			
		)
	)


);



	}


 ?>