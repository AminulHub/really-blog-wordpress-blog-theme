<?php 

/**
 * Here is all the settings, section, controls of Misc of Author Box in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_author_box( $wp_customize ){

		// Sanitize Checkbox
		function dt_author_box_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}


		// Setting a field value For Showing author box checkbox
		$wp_customize->add_setting( 'dt_author_box_show', [

			'default'				=>		'yes',
			'transport'				=>		'postMessage',
			'sanitize_callback'		=>		'dt_author_box_val',

		] );

		// Add a section for Author Box cusotmizer options
		$wp_customize->add_section( 'dt_author_section', [

			'title'			=>		esc_html__( 'Author Box', 'cmb2theme' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		] );

		// Showing a field for author box show or hide option
		$wp_customize->add_control( new WP_Customize_Control( 

			$wp_customize,
			'dt_author_box_show_set',
			array(

				'label'		=>		esc_html__( 'Show Author Box', 'cmb2theme' ),
				'section'	=>		'dt_author_section',
				'settings'	=>		'dt_author_box_show',
				'type'		=>		'checkbox',
				'choices'	=>		[

					'yes'	=>		'Yes',
					'no'	=>		'No'

				]

			)

		 ) );

	}

 ?>