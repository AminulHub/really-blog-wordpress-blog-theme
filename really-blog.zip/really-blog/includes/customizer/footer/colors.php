<?php 

/**
 * Here is all the settings, section, controls of Footer Section colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_footer_colors( $wp_customize ){

	// Set a field value Footer Background Color
	$wp_customize->add_setting( 'dt_ft_bg_color', [

		'default'				=>		'#222222',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a filed value Footer bar text color
	$wp_customize->add_setting( 'dt_ft_bar_text_color', [

		'default'				=>		'#c1c1c1',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for footer bar bg color
	$wp_customize->add_setting( 'dt_ft_bar_bg_color', [

		'default'				=>		'#1d1d1d',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Add a section for Footer Colors
	$wp_customize->add_section( 'dt_ft_colors', [

		'title'			=>		esc_html__( 'Footer Colors', 'cmb2theme' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );

	// Add a field for Footer Background color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_ft_bg_color_set',
		array(  

			'label'		=>		esc_html__( 'Footer Background Color', 'cmb2theme' ),
			'section'	=>		'dt_ft_colors',
			'settings'	=>		'dt_ft_bg_color',
		)
	)

);


	// Add a field for Footer bar bg color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_ft_menu_color_set',
		array(  

			'label'		=>		esc_html__( 'Footer Bar Background Color', 'cmb2theme' ),
			'section'	=>		'dt_ft_colors',
			'settings'	=>		'dt_ft_menu_color',
		)
	)


);

	// Add a field for Footer Bar text color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_ft_bar_text_color_set',
		array(  

			'label'		=>		esc_html__( 'Footer Bar Text Color', 'cmb2theme' ),
			'section'	=>		'dt_ft_colors',
			'settings'	=>		'dt_ft_bar_text_color',
		)
	)


);

	// Add a field for footer bar bg color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_ft_bar_bg_color_set',
		array(  

			'label'		=>		esc_html__( 'Footer Bar Background Color', 'cmb2theme' ),
			'section'	=>		'dt_ft_colors',
			'settings'	=>		'dt_ft_bar_bg_color',
		)
	)


);




	}

 ?>