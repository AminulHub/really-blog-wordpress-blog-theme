<?php 

/**
 * Here is all the settings, section, controls of Footer Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function dt_footer_misc( $wp_customize ){

	// Sanitize Checkbox
		function dt_footer_misc_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}

	// Set a field value for show or hide footer menu
	$wp_customize->add_setting( 'dt_footer_menu', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_footer_misc_val',

	] );

	// Set a field value for footer copyright text
	$wp_customize->add_setting( 'dt_footer_copyright', [

		'default'		=>		__( '© Copyright 2021. <a href="#">Dotted</a> HTML Template. All right reserved.', 'cmb2theme' )

	] );

	// Add a section for footer
	$wp_customize->add_section( 'dt_footer_section', [

		'title'			=>		esc_html__( 'Footer', 'cmb2theme' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );

	// Add a field for show or hide Footer menu
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_footer_menu_set',
		array(  

			'label'		=>		esc_html__( 'Show Footer Menu', 'cmb2theme' ),
			'section'	=>		'dt_footer_section',
			'settings'	=>		'dt_footer_menu',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);


	// Add a field for copyright text
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_footer_copyright_set',
		array(  

			'label'		=>		esc_html__( 'Copyright Text', 'cmb2theme' ),
			'section'	=>		'dt_footer_section',
			'settings'	=>		'dt_footer_copyright'

		)

	)

);


}

?>