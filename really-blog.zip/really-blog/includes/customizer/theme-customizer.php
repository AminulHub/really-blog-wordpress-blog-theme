<?php 

/**
 * This is the main file of the customizer settings, secitons, controls. This file is attached with 'customize_register' hook in functions.php
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/customize_register/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_customize_api( $wp_customize ){

		dt_header_misc( $wp_customize ); // Header customizer misc
		dt_top_bar_info(  $wp_customize ); // Header Top Bar customizer
		dt_header_colors( $wp_customize ); // Header customizer Colors
		dt_footer_colors( $wp_customize ); // Footer customizer colors
		dt_global_colors( $wp_customize ); // Global customizer colors
		cm_sd_widget_colors( $wp_customize ); // Sidebar & Footer widgets customizer colors
		cm_widget_misc( $wp_customize ); // Sidebar & Footer widgets customizer misc
		cm_blog_colors( $wp_customize ); // Single blog post customizer colors
		dt_author_box( $wp_customize ); // Author box customizer Misc
		dt_author_color( $wp_customize ); // Author box customizer colors
		dt_related_posts($wp_customize); // Related posts & projects customizer misc
		dt_rpost_colors( $wp_customize ); // Related posts & projects customizer colors
		dt_project_customize($wp_customize); // Single project customizer misc
		dt_project_colors( $wp_customize ); // Single project customizer colors
		dt_team_colors( $wp_customize ); // Team member customizer colors
		dt_comment_colors( $wp_customize ); // Comment section customizer colors
		dt_footer_misc( $wp_customize ); // Footer customizer misc

		// Add a theme panel
		$wp_customize->add_panel( 'dt_customizer_panel', [

			'title'		=>		esc_html__( 'Really Blog', 'really-blog' ),
			'priority'	=>		25

		] );

		// Changing the wordpress default panel word 'Site Title' to 'General'
		$wp_customize->get_section( 'title_tagline' )->title		=		esc_html__( 'General', 'really-blog' );

	}



 ?>