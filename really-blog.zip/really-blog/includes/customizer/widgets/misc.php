<?php 

/**
 * Here is all the settings, section, controls of Sidebars & Footer Widgets Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function cm_widget_misc( $wp_customize ){

		// Sanitize Checkbox
		function cm_widget_misc_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}

		// Set a field value for Footer social icons show or hide
		$wp_customize->add_setting( 'cm_fwid_social_icons', [

			'default'				=>		'yes',
			'sanitize_callback'		=>		'cm_widget_misc_val',

		]);

		// Add a section for widget
		$wp_customize->add_section( 'cm_widget_section', [

			'title'		=>		esc_html__( 'Widget', 'really-blog' ),
			'priority'	=>		30,
			'panel'		=>		'dt_customizer_panel'

		]);

		// Add a field for footer social icons show or hide
		$wp_customize->add_control( new WP_Customize_Control( 

			$wp_customize,
			'cm_fwid_social_icons_set',
			array(

				'label'		=>		esc_html__( 'Hide Social Icons', 'really-blog' ),
				'settings'	=>		'cm_fwid_social_icons',
				'section'	=>		'cm_widget_section',
				'type'		=>		'checkbox',
				'choices'	=>		[

					'yes'	=>		'Yes',
					'no'	=>		'No'

				]

			)

		 ) );

	}


 ?>