<?php 

/**
 * Here is all the settings, section, controls of Related Posts & Related Projects Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_related_posts($wp_customize){

		// Sanitize Checkbox
		function dt_related_posts_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}

		// Set a field related posts & projects show or hide
		$wp_customize->add_setting( 'dt_related_post_show', [

			'default'				=>		'yes',
			'transport'				=>		'postMessage',
			'sanitize_callback'		=>		'dt_related_posts_val',

		] );

		// Add a section for Related posts & projects show or hide 
		$wp_customize->add_section( 'dt_related_post_section', [

			'title'			=>		esc_html__( 'Related Posts', 'really-blog' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		] );

		// Add a field for show or hide of rp posts & projects
		$wp_customize->add_control( new WP_Customize_Control( 

			$wp_customize,
			'dt_related_post_show_set',
			array(

				'label'		=>		esc_html__( 'Show Related Posts Box', 'really-blog' ),
				'section'	=>		'dt_related_post_section',
				'settings'	=>		'dt_related_post_show',
				'type'		=>		'checkbox',
				'choices'	=>		[

					'yes'	=>		'Yes',
					'no'	=>		'No'

				]

			)

		 ) );

	}

 ?>