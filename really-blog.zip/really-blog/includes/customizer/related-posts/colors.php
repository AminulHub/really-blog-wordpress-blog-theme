<?php 

/**
 * Here is all the settings, section, controls of Related Posts & Projects colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function dt_rpost_colors( $wp_customize ){

	// Set a field value for related posts & projects headings
	$wp_customize->add_setting( 'dt_rp_title', [

		'default'				=>		'#444444',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for carousel icons
	$wp_customize->add_setting( 'dt_rp_icon', [

		'default'				=>		'#222222',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for carousel icons hover color
	$wp_customize->add_setting( 'dt_rp_icon_hover', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Add a section for Related posts & projects
	$wp_customize->add_section( 'dt_related_post_section', [

		'title'			=>		esc_html__( 'Related Posts & Projects', 'really-blog' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );

	// Add a field for headings color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_rp_title_set',
		array(  

			'label'		=>		esc_html__( 'Title Color', 'really-blog' ),
			'section'	=>		'dt_related_post_section',
			'settings'	=>		'dt_rp_title',
		)
	)

);

	// Add a field for carousel icons color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_rp_icon_set',
		array(  

			'label'		=>		esc_html__( 'Icon Color', 'really-blog' ),
			'section'	=>		'dt_related_post_section',
			'settings'	=>		'dt_rp_icon',
		)
	)


);

	// Add a field for icons hover color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_rp_icon_hover_set',
		array(  

			'label'		=>		esc_html__( 'Icon Hover Color', 'really-blog' ),
			'section'	=>		'dt_related_post_section',
			'settings'	=>		'dt_rp_icon_hover',
		)
	)


);

}

?>