<?php 

/**
 * Here is all the settings, section, controls of Top Bar Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function dt_top_bar_info(  $wp_customize ){

	// Set a field value for custom logo size
	$wp_customize->add_setting( 'dt_header_logo', [

		'default'				=>		'50%',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar fb handle
	$wp_customize->add_setting( 'dt_top_fb_handle', [

		'default'				=>		'your_handle',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar twitter handle
	$wp_customize->add_setting( 'dt_top_twitter_handle', [

		'default'				=>		'your_handle',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar instagram handle
	$wp_customize->add_setting( 'dt_top_insta_handle', [

		'default'				=>		'your_handle',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar tumblr handle
	$wp_customize->add_setting( 'dt_top_tumb_handle', [

		'default'				=>		'your_handle',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar linkedin handle
	$wp_customize->add_setting( 'dt_top_gplus_handle', [

		'default'				=>		'your_handle',
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar phone number
	$wp_customize->add_setting( 'dt_top_p_number', [

		'default'				=>		esc_html__( '312 88 098', 'cmb2theme' ),
		'sanitize_callback'		=>		'sanitize_text_field',

	] );

	// Set a field value for top bar email
	$wp_customize->add_setting( 'dt_top_email', [

		'default'				=>		esc_html__( 'info@example.com', 'cmb2theme' ),
		'sanitize_callback'		=>		'sanitize_email',

	] );

	// Add a section for Header
	$wp_customize->add_section( 'dt_header_section', [

		'title'			=>		esc_html__( 'Header', 'cmb2theme' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );

// Add a field for custom log size for header
$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_logo_set',
		array(  

			'label'		=>		esc_html__( 'Header Logo Size (%)', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_logo',
		)
	)


);

	// Add a field for fb handle
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_fb',
		array(  

			'label'		=>		esc_html__( 'Facebook Handle', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_fb_handle',
		)
	)


);

	// Add a field for Twitter handle
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_twt',
		array(  

			'label'		=>		esc_html__( 'Twitter Handle', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_twitter_handle',
		)
	)


);

	// Add a field for Instagram handle
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_ins',
		array(  

			'label'		=>		esc_html__( 'Instagram Handle', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_insta_handle',
		)
	)


);

	// Add a field for Tumblr handle
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_tumb',
		array(  

			'label'		=>		esc_html__( 'Tumblr Handle', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_tumb_handle',
		)
	)


);

	// Add a field for Linkedin handle
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_gplus',
		array(  

			'label'		=>		esc_html__( 'Linkedin Handle', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_gplus_handle',
		)
	)


);

		// Add a field for Phone Number
		$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_p_number_set',
		array(  

			'label'		=>		esc_html__( 'Phone Number', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_p_number',
		)
	)


);

	// Add a field for Email
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_email_set',
		array(  

			'label'		=>		esc_html__( 'Your Email', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_email',
		)
	)


);

	


}



?>