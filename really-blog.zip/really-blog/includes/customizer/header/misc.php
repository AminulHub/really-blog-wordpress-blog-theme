<?php 

/**
 * Here is all the settings, section, controls of Header section Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function dt_header_misc( $wp_customize ){

	// Sanitize Checkbox
		function dt_header_misc_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}


	// Set a field value for Mobile Header Search Box
	$wp_customize->add_setting( 'dt_header_mbl_search_box', [

		'default'				=>		'yes',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for Sticky header show or hide
	$wp_customize->add_setting( 'dt_header_sticked', [

		'default'				=>		'yes',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for Top Bar show or hide
	$wp_customize->add_setting( 'dt_top_bar_show', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for header bottom shadow line show or hide
	$wp_customize->add_setting( 'dt_header_btm_border', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for header bottom border show or hide
	$wp_customize->add_setting( 'dt_header_btm_border_2', [

		'default'				=>		'yes',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for top bar menu shor or hide
	$wp_customize->add_setting( 'dt_top_bar_menu', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for header search icon show or hide 
	$wp_customize->add_setting( 'dt_header_search_icon', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for header breadcrumb show or hide
	$wp_customize->add_setting( 'dt_header_breadcrumb', [

		'default'				=>		'yes',
		'transport'				=>		'postMessage',
		'sanitize_callback'		=>		'dt_header_misc_val',

	] );

	// Set a field value for site tagline show or hide in header
	$wp_customize->add_setting( 'dt_header_tagline_showed', [

		'default'				=>		'yes',
		'sanitize_callback'		=>		'dt_header_misc_val',	

	] );

	// Add a section for Header
	$wp_customize->add_section( 'dt_header_section', [

		'title'			=>		esc_html__( 'Header', 'cmb2theme' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );

	// Add a field for Sticky header misc
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_sticked_set',
		array(  

			'label'		=>		esc_html__( 'Hide Sticky Header', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_sticked',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for top bar show or hide
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_show_set',
		array(  

			'label'		=>		esc_html__( 'Show Top Bar', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_bar_show',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for Header bottom shadow line
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_btm_border_set',
		array(  

			'label'		=>		esc_html__( 'Header Bottom Line', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_btm_border',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for Header bottom border
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_btm_border_2_set',
		array(  

			'label'		=>		esc_html__( 'Hide Header Border', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_btm_border_2',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for top bar menu show or hide
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_top_bar_set',
		array(  

			'label'		=>		esc_html__( 'Show Top Bar Menu', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_top_bar_menu',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for header search icon
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_search_icon_set',
		array(  

			'label'		=>		esc_html__( 'Header Search Icon', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_search_icon',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for breadcrumg show or hide
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_breadcrumb_set',
		array(  

			'label'		=>		esc_html__( 'Show Breadcrumb', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_breadcrumb',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);

	// Add a field for tagline show or hide
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_tagline_showed_set',
		array(  

			'label'		=>		esc_html__( 'Show Tagline', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_tagline_showed',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);


// Add a field for tagline show or hide
	$wp_customize->add_control( new WP_Customize_Control(

		$wp_customize,
		'dt_header_mbl_search_box_set',
		array(  

			'label'		=>		esc_html__( 'Show Mobile Top Search Box', 'cmb2theme' ),
			'section'	=>		'dt_header_section',
			'settings'	=>		'dt_header_mbl_search_box',
			'type'		=>		'checkbox',
			'choices'	=>		[

				'yes'		=>		'Yes',
				'no'		=>		'No'

			]

		)

	)

);



}

?>