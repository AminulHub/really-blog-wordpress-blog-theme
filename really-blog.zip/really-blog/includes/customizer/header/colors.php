<?php 

/**
 * Here is all the settings, section, controls of Header Section colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function dt_header_colors( $wp_customize ){

	// Set a field value for site name color
	$wp_customize->add_setting( 'dt_site_name', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for stie tagline color
	$wp_customize->add_setting( 'dt_site_tagline', [

		'default'				=>		'#666666',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Top bar Background Color
	$wp_customize->add_setting( 'dt_top_bar_color', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Header Background Color
	$wp_customize->add_setting( 'dt_header_bg_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Top Bar Menu Text Color
	$wp_customize->add_setting( 'dt_top_bar_menu_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Tob Bar Phone Number & Email Colors
	$wp_customize->add_setting( 'dt_top_bar_info_color', [

		'default'				=>		'#000000',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Top Bar Social Icons Background Color
	$wp_customize->add_setting( 'dt_top_bar_icons_bg_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Top Bar Social Icons Colors
	$wp_customize->add_setting( 'dt_top_bar_icons_color', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );


	// Header Menu Background Color
	$wp_customize->add_setting( 'dt_main_menu_bg_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu text color
	$wp_customize->add_setting( 'dt_main_menu_color', [

		'default'				=>		'#000000',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu hover text color
	$wp_customize->add_setting( 'dt_main_menu_color_hover', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu divide color
	$wp_customize->add_setting( 'dt_main_menu_li_line_color', [

		'default'				=>		'#000000',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu's sub menu text color
	$wp_customize->add_setting( 'dt_main_menu_sub_color', [

		'default'				=>		'#4f4045',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu's sub menu hover text color
	$wp_customize->add_setting( 'dt_main_menu_sub_color_hover', [

		'default'				=>		'#deb152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header main menu's sub menu text color
	$wp_customize->add_setting( 'dt_main_menu_sub_txt_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header sub menu hover text color
	$wp_customize->add_setting( 'dt_main_menu_sub_txt_hover_color', [

		'default'				=>		'#ffffff',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Set a field value for header search icon color
	$wp_customize->add_setting( 'dt_header_s_icon_cl', [

		'default'				=>		'#DEB152',
		'sanitize_callback'		=>		'sanitize_hex_color',

	] );

	// Add a section for Header Colors
	$wp_customize->add_section( 'dt_colors', [

		'title'			=>		esc_html__( 'Header Colors', 'cmb2theme' ),
		'priority'		=>		30,
		'panel'			=>		'dt_customizer_panel'

	] );


	// Add a field for Site name color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_site_name_set',
		array(  

			'label'		=>		esc_html__( 'Site Name Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_site_name',
		)
	)

);

	// Add a field for site tagline color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_site_tagline_set',
		array(  

			'label'		=>		esc_html__( 'Site Tagline Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_site_tagline',
		)
	)


);

	// Add a field for Top bar bg color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_top_bar_color_set',
		array(  

			'label'		=>		esc_html__( 'Tob Bar Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_top_bar_color',
		)
	)


);

	// Add a field for header background color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_header_bg_color_set',
		array(  

			'label'		=>		esc_html__( 'Header Background Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_header_bg_color',
		)
	)


);

	// Add a field for Top bar menu color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_top_bar_menu_color_set',
		array(  

			'label'		=>		esc_html__( 'Tob Bar Menu Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_top_bar_menu_color',
		)
	)


);

	// Add a field for Top bar info color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_top_bar_info_color_set',
		array(  

			'label'		=>		esc_html__( 'Tob Bar Info Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_top_bar_info_color',
		)
	)


);

	// Add a field for top bar background icons color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_top_bar_icons_bg_color_set',
		array(  

			'label'		=>		esc_html__( 'Tob Bar Icons Background Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_top_bar_icons_bg_color',
		)
	)


);

	// Add a field for Top bar Icons color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_top_bar_icons_color_set',
		array(  

			'label'		=>		esc_html__( 'Tob Bar Icons Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_top_bar_icons_color',
		)
	)


);

	// Add a field for Main Menu Background color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_bg_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Background Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_bg_color',
		)
	)


);

	// Add a field for Main menu text color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_color',
		)
	)


);

	// Add a field for Main menu hover text color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_color_hover_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Hover Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_color_hover',
		)
	)


);

	// Add a field for Main menu divide line color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_li_line_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Line Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_li_line_color',
		)
	)


);

	// Add a field for Main Menu sub menu bg color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_sub_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Sub Background Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_sub_color',
		)
	)


);

	// Add a field for Main Menu sub menu hover color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_sub_color_hover_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Sub Hover Background Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_sub_color_hover',
		)
	)


);

	
	// Add a field for Main menu sub menu text color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_sub_txt_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Sub Menu Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_sub_txt_color',
		)
	)


);

	// Add a field for Main Menu sub menu hover text color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_main_menu_sub_txt_hover_color_set',
		array(  

			'label'		=>		esc_html__( 'Main Menu Sub Hover Text Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_main_menu_sub_txt_hover_color',
		)
	)


);

	// Add a field for Search icon color
	$wp_customize->add_control( new WP_Customize_Color_Control(

		$wp_customize,
		'dt_header_s_icon_cl_set',
		array(  

			'label'		=>		esc_html__( 'Search Icon Color', 'cmb2theme' ),
			'section'	=>		'dt_colors',
			'settings'	=>		'dt_header_s_icon_cl',
		)
	)


);


}

?>