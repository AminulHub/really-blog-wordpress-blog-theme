<?php 

/**
 * Here is all the settings, section, controls of Comment Sections forms,list colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_comment_colors( $wp_customize ){

		// Set a field value for Comment Reply Button Bg color
		$wp_customize->add_setting( 'dt_cmnt_button', [

			'default'				=>	'#000000',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Set a field value for comment reply button text color
		$wp_customize->add_setting( 'dt_cmnt_txt_color', [

			'default'				=>	'#ffffff',
			'sanitize_callback'		=>		'sanitize_hex_color',

		]);

		// Add a section for Comment
		$wp_customize->add_section( 'dt_cmnt_section', [

			'title'		=>		esc_html__( 'Comment', 'really-blog' ),
			'priority'	=>		30,
			'panel'		=>		'dt_customizer_panel'

		]);

		// Add a field for Reply Button Bg color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_cmnt_button_set',
			array(

				'label'		=>		esc_html__( 'Reply Button Color', 'really-blog' ),
				'settings'	=>		'dt_cmnt_button',
				'section'	=>		'dt_cmnt_section'

			)

		) );

		// Add a field for Reply button text color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_cmnt_txt_color_set',
			array(

				'label'		=>		esc_html__( 'Reply Button Text Color', 'really-blog' ),
				'settings'	=>		'dt_cmnt_txt_color',
				'section'	=>		'dt_cmnt_section'

			)

		) );

	}

?>