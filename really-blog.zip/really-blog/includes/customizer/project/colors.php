<?php 

/**
 * Here is all the settings, section, controls of Single Project page colors in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_project_colors( $wp_customize ){

		// Set a field value for project single page heading color
		$wp_customize->add_setting( 'dt_pro_head_color', [

			'default'				=>		'#444444',
			'sanitize_callback'		=>		'sanitize_hex_color',


		] );

		// Set a field value for project single page skill icons background color
		$wp_customize->add_setting( 'dt_pro_skill_icon', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',


		] );

		// Set a field value for project single page launch button color
		$wp_customize->add_setting( 'dt_pro_btn_color', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',


		] );

		// Set a field value for launch button hover color
		$wp_customize->add_setting( 'dt_pro_btn_hover_color', [

			'default'				=>		'#444444',
			'sanitize_callback'		=>		'sanitize_hex_color',


		] );

		// Add a section for Project
		$wp_customize->add_section( 'dt_pro_section', [

			'title'			=>		esc_html__( 'Project', 'really-blog' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		]);

		// Add a field for project single page heading color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_pro_head_color_set',
			array(

				'label'		=>		esc_html__( 'Headings Color', 'really-blog' ),
				'settings'	=>		'dt_pro_head_color',
				'section'	=>		'dt_pro_section'

			)

		) );

		// Add a field for skills icon bg color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_pro_skill_icon_set',
			array(

				'label'		=>		esc_html__( 'Skills Icons Color', 'really-blog' ),
				'settings'	=>		'dt_pro_skill_icon',
				'section'	=>		'dt_pro_section'

			)

		) );

		// Add a field for launch button
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_pro_btn_color_set',
			array(

				'label'		=>		esc_html__( 'Launch Button Color', 'really-blog' ),
				'settings'	=>		'dt_pro_btn_color',
				'section'	=>		'dt_pro_section'

			)

		) );

		// Add a field for launch button hover color
		$wp_customize->add_control( new WP_Customize_Color_Control(

			$wp_customize,
			'dt_pro_btn_hover_color_set',
			array(

				'label'		=>		esc_html__( 'Launch Button Hover Color', 'really-blog' ),
				'settings'	=>		'dt_pro_btn_hover_color',
				'section'	=>		'dt_pro_section'

			)

		) );

	}

 ?>