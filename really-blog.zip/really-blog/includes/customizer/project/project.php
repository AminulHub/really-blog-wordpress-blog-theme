<?php 

/**
 * Here is all the settings, section, controls of Single Project Misc in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_project_customize($wp_customize){

		// Sanitize Checkbox
		function dt_project_customize_val( $input ) {
	    if ( $input === true || $input === '1' ) {
	        return '1';
	    }
	    return '';
	}

		// Set a field value for project launch button show or hide
		$wp_customize->add_setting( 'dt_pro_show', [

			'default'				=>		'yes',
			'transport'				=>		'postMessage',
			'sanitize_callback'		=>		'dt_project_customize_val',

		]);

		// Add a section for Project
		$wp_customize->add_section( 'dt_pro_section', [

			'title'			=>		esc_html__( 'Project', 'cmb2theme' ),
			'priority'		=>		30,
			'panel'			=>		'dt_customizer_panel'

		]);

		// Add a field for launch button show or hide
		$wp_customize->add_control( new WP_Customize_Control(

			$wp_customize,
			'dt_pro_show_set',
			array(

				'label'		=>		esc_html__( 'Show Launch Button', 'cmb2theme' ),
				'settings'	=>		'dt_pro_show',
				'section'	=>		'dt_pro_section',
				'type'		=>		'checkbox',
				'choices'	=>		[

					'yes'	=>		'Yes',
					'no'	=>		'No'

				]

			)

		) );

	}

 ?>