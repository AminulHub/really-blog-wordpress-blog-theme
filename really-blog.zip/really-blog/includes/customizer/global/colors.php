<?php 

/**
 * Here is all the settings, section, controls of Global colors of the site in the customizer.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/customize-api/customizer-objects/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_global_colors( $wp_customize ){

		// Set a field value for website paragraph color
		$wp_customize->add_setting( 'dt_body_color', [

			'default'				=>		'#666666',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for website headings color
		$wp_customize->add_setting( 'dt_h_color', [

			'default'				=>		'#444444',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for website anchor color
		$wp_customize->add_setting( 'dt_a_color', [

			'default'				=>		'#337ab7',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for website buttons color
		$wp_customize->add_setting( 'dt_button_color', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for website buttons text color
		$wp_customize->add_setting( 'dt_button_txt_color', [

			'default'				=>		'#ffffff',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for go to top bg color
		$wp_customize->add_setting( 'dt_go_top_color', [

			'default'				=>		'#000000',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for go to top icon color
		$wp_customize->add_setting( 'dt_go_top_icon_color', [

			'default'				=>		'#ffffff',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Set a field value for go to top hover color
		$wp_customize->add_setting( 'dt_go_top_hover_color', [

			'default'				=>		'#DEB152',
			'sanitize_callback'		=>		'sanitize_hex_color',

		] );

		// Add a section for Global
		$wp_customize->add_section( 'dt_global_section', [

			'title'		=>		esc_html__( 'Global Colors', 'really-blog' ),
			'priority'	=>		30,
			'panel'		=>		'dt_customizer_panel'

		] );

		// Add a field for website pragraph color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_body_color_set',
			array(

				'label'			=>		esc_html__( 'Body Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_body_color'

			)

		 ) );

		// Add a field for website anchor color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_a_color_set',
			array(

				'label'			=>		esc_html__( 'Anchor Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_a_color'

			)

		 ) );

		// Add a field for website Headings color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_h_color_set',
			array(

				'label'			=>		esc_html__( 'Headings Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_h_color'

			)

		 ) );

		// Add a field for website Button color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_button_color_set',
			array(

				'label'			=>		esc_html__( 'Button Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_button_color'

			)

		 ) );

		// Add a field for website buttons text color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_button_txt_color_set',
			array(

				'label'			=>		esc_html__( 'Button Text Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_button_txt_color'

			)

		 ) );

		// Add a field for 'go to top' button bg color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_go_top_color',
			array(

				'label'			=>		esc_html__( 'Go To Top Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_go_top_color'

			)

		 ) );

		// Add a field for 'go to top' icon color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_go_top_icon_color_set',
			array(

				'label'			=>		esc_html__( 'Go To Top Icon Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_go_top_icon_color'

			)

		 ) );

		// Add a field for 'go to top' hover color
		$wp_customize->add_control( new WP_Customize_Color_Control( 

			$wp_customize,
			'dt_go_top_hover_color_set',
			array(

				'label'			=>		esc_html__( 'Go To Top Hover Color', 'really-blog' ),
				'section'		=>		'dt_global_section',
				'settings'		=>		'dt_go_top_hover_color'

			)

		 ) );


	}

?>