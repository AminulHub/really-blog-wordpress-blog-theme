<?php 

/**
 * This file works to change the customizer preview styles. Here we iclude the css and js files of the customize preview. This only works if 'transport' of any field setting is 'postMessage'. This file is attached wtih 'customize_preview_init' hook in functions.php
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/customize_preview_init/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_customize_preview(){

		// Customizer Preview Override Js file
		wp_enqueue_script( 'dt_preview_js', esc_url(get_template_directory_uri()). '/assets/js/theme-customizer.js', [ 'jquery', 'customize-preview' ], '', true );

	}

?>