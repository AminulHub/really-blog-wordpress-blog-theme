<?php 

function custom_taxonomy() {
	
	/**
 *This file loads after wordpress complete the loads but before any header loads. Here custom post type, custom taxonomy etc. can be setup. This file is attached with 'init' action hook in functions.php
  *
 * @package     Really Blog
 * @link        https://developer.wordpress.org/reference/hooks/init/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}



    // Labels For Custom Post Type 'Projects'
    $labels = array(
        'name'                  => _x( 'Projects', 'Post type general name', 'cmb2theme' ),
        'singular_name'         => _x( 'Project', 'Post type singular name', 'cmb2theme' ),
        'menu_name'             => _x( 'Projects', 'Admin Menu text', 'cmb2theme' ),
        'name_admin_bar'        => _x( 'Project', 'Add New on Toolbar', 'cmb2theme' ),
        'add_new'               => __( 'Add New', 'cmb2theme' ),
        'add_new_item'          => __( 'Add New Project', 'cmb2theme' ),
        'new_item'              => __( 'New Project', 'cmb2theme' ),
        'edit_item'             => __( 'Edit Project', 'cmb2theme' ),
        'view_item'             => __( 'View Project', 'cmb2theme' ),
        'all_items'             => __( 'All Projects', 'cmb2theme' ),
        'search_items'          => __( 'Search Projects', 'cmb2theme' ),
        'parent_item_colon'     => __( 'Parent Projects:', 'cmb2theme' ),
        'not_found'             => __( 'No Projects found.', 'cmb2theme' ),
        'not_found_in_trash'    => __( 'No Projects found in Trash.', 'cmb2theme' ),
        'featured_image'        => _x( 'Project Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'archives'              => _x( 'Project archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'cmb2theme' ),
        'insert_into_item'      => _x( 'Insert into Project', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'cmb2theme' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Project', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'cmb2theme' ),
        'filter_items_list'     => _x( 'Filter Projects list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'cmb2theme' ),
        'items_list_navigation' => _x( 'Projects list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'cmb2theme' ),
        'items_list'            => _x( 'Projects list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'cmb2theme' ),
    );
 
    // Argumnet array for 'Projects'
    $args = array(
        'labels'             => $labels,
        'description'		 =>	esc_html__( 'Create your first Project', 'cmb2theme' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'project' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 25,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
        'taxonomies'         => array( 'proskills' ),
        'show_in_rest'		 =>	true
    );
 
    // Registering custom post type 'Projects'
    register_post_type( 'projects', $args );

    // Labels of custom taxonomy Taxonomy for custom post type 'Projects'
    $tx_labels = array(
        'name'              => _x( 'Project Skills', 'taxonomy general name', 'cmb2theme' ),
        'singular_name'     => _x( 'Project Skill', 'taxonomy singular name', 'cmb2theme' ),
        'search_items'      => __( 'Search Project Skills', 'cmb2theme' ),
        'all_items'         => __( 'All Project Skills', 'cmb2theme' ),
        'parent_item'       => __( 'Parent Skill', 'cmb2theme' ),
        'parent_item_colon' => __( 'Parent Skill:', 'cmb2theme' ),
        'edit_item'         => __( 'Edit Skill', 'cmb2theme' ),
        'update_item'       => __( 'Update Skill', 'cmb2theme' ),
        'add_new_item'      => __( 'Add Project New Skill', 'cmb2theme' ),
        'new_item_name'     => __( 'New Project Skill Name', 'cmb2theme' ),
        'menu_name'         => __( 'Project Skills', 'cmb2theme' ),
    );
 
    // Arguments of custom taxonomy for custom post type 'Projects'
    $tx_args = array(
        'hierarchical'      =>  true,
        'labels'            =>  $tx_labels,
        'description'       =>  esc_html__( 'Add Skills', 'cmb2theme' ),
        'public'            =>  true,
        'publicly_queryable'=>  true,
        'show_in_menu'      =>  true,
        'show_in_rest'      =>  true,
        'default_term'      =>  [ 'name'    =>  esc_html__( 'Uncategorized', 'cmb2theme' ), 'slug' =>  'uncategorized' ],
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'proskills' ),
    );
 
    // Registering custom taxonomy 'proskills' for Projects
    register_taxonomy( 'proskills', array( 'projects' ), $tx_args );




    // Labels of custom post type 'Team'
    $labels_t = array(
        'name'                  => _x( 'Teams', 'Post type general name', 'cmb2theme' ),
        'singular_name'         => _x( 'Team', 'Post type singular name', 'cmb2theme' ),
        'menu_name'             => _x( 'Teams', 'Admin Menu text', 'cmb2theme' ),
        'name_admin_bar'        => _x( 'Team', 'Add New on Toolbar', 'cmb2theme' ),
        'add_new'               => __( 'Add New', 'cmb2theme' ),
        'add_new_item'          => __( 'Add New Team', 'cmb2theme' ),
        'new_item'              => __( 'New Team', 'cmb2theme' ),
        'edit_item'             => __( 'Edit Team', 'cmb2theme' ),
        'view_item'             => __( 'View Team', 'cmb2theme' ),
        'all_items'             => __( 'All Teams', 'cmb2theme' ),
        'search_items'          => __( 'Search Teams', 'cmb2theme' ),
        'parent_item_colon'     => __( 'Parent Teams:', 'cmb2theme' ),
        'not_found'             => __( 'No Teams found.', 'cmb2theme' ),
        'not_found_in_trash'    => __( 'No Teams found in Trash.', 'cmb2theme' ),
        'featured_image'        => _x( 'Team Memeber Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'set_featured_image'    => _x( 'Set Member Image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'cmb2theme' ),
        'archives'              => _x( 'Team archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'cmb2theme' ),
        'insert_into_item'      => _x( 'Insert into Team', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'cmb2theme' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Team', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'cmb2theme' ),
        'filter_items_list'     => _x( 'Filter Teams list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'cmb2theme' ),
        'items_list_navigation' => _x( 'Teams list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'cmb2theme' ),
        'items_list'            => _x( 'Teams list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'cmb2theme' ),
    );

    // Arguments for custom post type 'Team'
    $args_t = array(
        'labels'             => $labels_t,
        'description'        => esc_html__( 'Create Your Profile', 'cmb2theme' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'team' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 25,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
        'taxonomies'         => array( 'skills' ),
        'show_in_rest'       => true
    );
 
    // Registering custom post type 'Team'
    register_post_type( 'team', $args_t );

    // Labels of custom Taxonomy for post type 'Team'
    $tx_labels_t = array(
        'name'              => _x( 'Team Skills', 'taxonomy general name', 'cmb2theme' ),
        'singular_name'     => _x( 'Team Skill', 'taxonomy singular name', 'cmb2theme' ),
        'search_items'      => __( 'Search Team Skills', 'cmb2theme' ),
        'all_items'         => __( 'All Team Skills', 'cmb2theme' ),
        'parent_item'       => __( 'Team Parent Skill', 'cmb2theme' ),
        'parent_item_colon' => __( 'Team Parent Skill:', 'cmb2theme' ),
        'edit_item'         => __( 'Edit Team Skill', 'cmb2theme' ),
        'update_item'       => __( 'Update Team Skill', 'cmb2theme' ),
        'add_new_item'      => __( 'Add New Team Skill', 'cmb2theme' ),
        'new_item_name'     => __( 'New Team Skill Name', 'cmb2theme' ),
        'menu_name'         => __( 'Team Skills', 'cmb2theme' ),
    );
 
    // Arguments for custom taxonomy for custom post type 'Team'
    $tx_args_t = array(
        'hierarchical'      =>  true,
        'labels'            =>  $tx_labels_t,
        'description'       =>  esc_html__( 'Add Team Skills', 'cmb2theme' ),
        'public'            =>  true,
        'publicly_queryable'=>  true,
        'show_in_menu'      =>  true,
        'show_in_rest'      =>  true,
        'default_term'      =>  [ 'name'    =>  'Uncategorized', 'slug' =>  'uncategorized' ],
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'skills' ),
    );
 
    // Registering custom taxonomy 'skills' for custom post type 'Team'
    register_taxonomy( 'skills', array( 'team' ), $tx_args_t );


}


?>