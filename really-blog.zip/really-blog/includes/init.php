<?php 

function real_blog() {
	
	/**
 *This file loads after wordpress complete the loads but before any header loads. Here custom post type, custom taxonomy etc. can be setup. This file is attached with 'init' action hook in functions.php
  *
 * @package     Really Blog
 * @link        https://developer.wordpress.org/reference/hooks/init/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}


}


?>