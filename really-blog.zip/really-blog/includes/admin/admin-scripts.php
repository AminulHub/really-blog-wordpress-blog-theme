<?php 

/**
 * This file loads any custom Js and Css files for Admin pages. Here all custom Js and Css included for Admin pages. This file attached with 'admin_enqueue-scripts' action hook in functions.php
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/admin_enqueue_scripts/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	function dt_admin_files(){

		wp_register_script( 'dt_cmb2_logic', esc_url(get_template_directory_uri()). '/extensions/cmb2-logics/cmb2-conditionals.js', [], '', true );
		wp_enqueue_script( 'dt_cmb2_logic' );

	}

 ?>
