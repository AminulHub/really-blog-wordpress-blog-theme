<div style="display: none;">
										<?php 

										register_block_style();
										register_block_pattern();
										add_editor_style();

										 ?>
									</div>