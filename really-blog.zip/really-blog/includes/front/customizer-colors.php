<?php

 /**
 * Here all the customizer colors values added to the style file with their selectors 'dt_theme_header_css'
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/classes/wp_customize_color_control/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

 if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

// Header Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'.logo-1 h2 a{ color:' .get_theme_mod('dt_site_name','#DEB152'). ' !important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.slogan-1{ color:' .get_theme_mod('dt_site_tagline','#666666'). ' !important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.topbar-1.bg-theme{ background:' .get_theme_mod('dt_top_bar_color','#DEB152'). ' !important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.header-v1{ background:' .get_theme_mod('dt_header_bg_color','#ffffff'). ' !important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.topbar-1-inner .menu-item a{ color:' .get_theme_mod('dt_top_bar_menu_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.topbar-info-1 li{ color:' .get_theme_mod('dt_top_bar_info_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.topbar-info-1 li span{ color:' .get_theme_mod('dt_top_bar_info_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.topbar-info-1 li a{ color:' .get_theme_mod('dt_top_bar_info_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.social-1 li a{ background:' .get_theme_mod('dt_top_bar_icons_bg_color','#ffffff'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.social-1 li a i{ color:' .get_theme_mod('dt_top_bar_icons_color','#DEB152'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-1 a{ color:' .get_theme_mod('dt_main_menu_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-1 li a:hover{ color:' .get_theme_mod('dt_main_menu_color_hover','#DEB152'). '!important'.'; }' 

);


wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-1{ background:' .get_theme_mod('dt_main_menu_bg_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.header-v1 .navi-level-1 a:after{ background:' .get_theme_mod('dt_main_menu_li_line_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-2 li a{ background:' .get_theme_mod('dt_main_menu_sub_color','#4f4045'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-3 li a{ background:' .get_theme_mod('dt_main_menu_sub_color','#4f4045'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-4 li a{ background:' .get_theme_mod('dt_main_menu_sub_color','#4f4045'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-2 li a:hover{ background:' .get_theme_mod('dt_main_menu_sub_color_hover','#deb152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-3 li a:hover{ background:' .get_theme_mod('dt_main_menu_sub_color_hover','#deb152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-4 li a:hover{ background:' .get_theme_mod('dt_main_menu_sub_color_hover','#deb152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-2 a{ color:' .get_theme_mod('dt_main_menu_sub_txt_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-3 a{ color:' .get_theme_mod('dt_main_menu_sub_txt_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-4 a{ color:' .get_theme_mod('dt_main_menu_sub_txt_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-2 li a:hover{ color:' .get_theme_mod('dt_main_menu_sub_txt_hover_color','#ffffff'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-3 li a:hover{ color:' .get_theme_mod('dt_main_menu_sub_txt_hover_color','#ffffff'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-level-4 li a:hover{ color:' .get_theme_mod('dt_main_menu_sub_txt_hover_color','#ffffff'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-right li a.btn-search-navi i{ color:' .get_theme_mod('dt_header_s_icon_cl','#DEB152'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-right li a.btn-search-navi{ color:' .get_theme_mod('dt_header_s_icon_cl','#DEB152'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-right li a i{ color:' .get_theme_mod('dt_header_c_icon_cl','#DEB152'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.navi-right li a{ color:' .get_theme_mod('dt_header_c_icon_cl','#DEB152'). '; }' 

);



// Footer Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'footer{ background:' .get_theme_mod('dt_ft_bg_color', '#222222' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.copyright-1 li a{ color:' .get_theme_mod( 'dt_ft_bar_text_color', '#c1c1c1' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.copyright-1 li::after{ color:' .get_theme_mod( 'dt_ft_bar_text_color', '#c1c1c1' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.text-copyright-1{ color:' .get_theme_mod('dt_ft_bar_text_color','#c1c1c1'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.text-copyright-1 a{ color:' .get_theme_mod('dt_ft_bar_text_color','#c1c1c1'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'#copyright-1{ background-color:' .get_theme_mod('dt_ft_bar_bg_color', '#1d1d1d'). '; }' 

);

		

// Global Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'#to-the-top{ background-color:' .get_theme_mod('dt_go_top_color','#000000'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'#to-the-top i{ color:' .get_theme_mod('dt_go_top_icon_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'#to-the-top:hover{ background-color:' .get_theme_mod('dt_go_top_hover_color','#DEB152'). '; }' 

);

		

// Author Box Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'.author-info h3{ color:' .get_theme_mod('dt_author_name','#444444'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.author-info h5{ color:' .get_theme_mod('dt_author_expert', '#deb152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.author-info p{ color:' .get_theme_mod('dt_author_des','#666666'). '; }' 

);



// Related Post Color
wp_add_inline_style( 'dt_theme_header_css', 

	'.relate-post .title-inline{ color:' .get_theme_mod('dt_rp_title','#444444'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.relate-project .title-inline{ color:' .get_theme_mod('dt_rp_title','#444444'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.customNavigation-1 a.btn-1{ color:' .get_theme_mod('dt_rp_icon','#222222'). '; border-color: ' .get_theme_mod('dt_rp_icon'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.customNavigation-1 a.btn-1:hover{ color:' .get_theme_mod('dt_rp_icon_hover','#DEB152'). '; border-color: ' .get_theme_mod('dt_rp_icon_hover'). '; }' 

);



// Global Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'h1,
	h2,
	h3,
	h4,
	h5,
	h6 { color:' .get_theme_mod('dt_h_color','#444444'). '!important'.'; }' 

);


wp_add_inline_style( 'dt_theme_header_css', 

	'body p{ color:' .get_theme_mod('dt_body_color','#666666'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body span{ color:' .get_theme_mod('dt_body_color','#666666'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body b{ color:' .get_theme_mod('dt_body_color','#666666'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body strong{ color:' .get_theme_mod('dt_body_color','#666666'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body a{ color:' .get_theme_mod('dt_a_color','#337ab7'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body button{ background-color:' .get_theme_mod('dt_button_color','#DEB152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'body button{ color:' .get_theme_mod('dt_button_txt_color','#ffffff'). '!important'. '; }' 

);




// Project Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'.porfolio-info-col h3{ color:' .get_theme_mod('dt_pro_head_color','#444444'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.relate-project h3{ color:' .get_theme_mod('dt_pro_head_color','#DEB152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.portfolio-feature-content .col-skill p i{ color:' .get_theme_mod('dt_pro_skill_icon','#DEB152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.portfolio-feature-content .col-description .ot-btn{ background:' .get_theme_mod('dt_pro_btn_color','#DEB152'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.portfolio-feature-content .col-description .ot-btn:hover{ background:' .get_theme_mod('dt_pro_btn_hover_color'). '!important'. '; }' 

);




// Team Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'div.single-team-warp h3{ color:' .get_theme_mod('dt_team_titles','#DEB152'). '!important'.'; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'div.chart-v-item .progress-bar.bar-chart{ background:' .get_theme_mod('dt_team_bar','#DEB152'). '; }' 

);



// Comment Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'.comment-body .reply a{ background:' .get_theme_mod('dt_cmnt_button','#000000'). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.comment-body .reply a{ color:' .get_theme_mod('dt_cmnt_txt_color','#ffffff'). '!important'. '; }' 

);



// Blog Colors
wp_add_inline_style( 'dt_theme_header_css', 

	'.date-time.bg-theme{ background:' .get_theme_mod('cm_date_box','#deb152'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.date-time .date,
	.month{ color:' .get_theme_mod('cm_date_txt_color','#ffffff'). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.blog-data .blog-type{ background:' .get_theme_mod( 'cm_blog_ptype_bg', '#444444' ). '!important'. '; }' 

);



// Widgets
wp_add_inline_style( 'dt_theme_header_css', 

	'.widget h3{ color:' .get_theme_mod( 'cm_wid_title_color', '#444444' ). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.widget a{ color:' .get_theme_mod( 'cm_wid_a_color', '#DEB152' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'.widget 
	p,
	span,
	b,
	strong{ color:' .get_theme_mod( 'cm_wid_p_color', '#666666' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget h3{ color:' .get_theme_mod( 'cm_fwid_t_color', '#ffffff' ). '!important'. '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget a{ color:' .get_theme_mod( 'cm_fwid_a_color', '#DEB152' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget p{ color:' .get_theme_mod( 'cm_fwid_p_color', '#666666' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget span{ color:' .get_theme_mod( 'cm_fwid_p_color', '#666666' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget b{ color:' .get_theme_mod( 'cm_fwid_p_color', '#666666' ). '; }' 

);

wp_add_inline_style( 'dt_theme_header_css', 

	'footer .widget strong{ color:' .get_theme_mod( 'cm_fwid_p_color', '#666666' ). '; }' 

);




?>