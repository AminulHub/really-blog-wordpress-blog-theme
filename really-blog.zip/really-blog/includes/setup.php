<?php  

	/**
 *This file loads after Theme loads. Here you can register menus, add theme supports like - widgets, menus, headers, title, custom logo etc. This file is attached with 'after_setup_theme' action hook in functions.php
  *
 * @package     Really Blog
 * @link        https://developer.wordpress.org/reference/hooks/after_setup_theme/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
    exit; // if accessed directly exit
}

	function dt_setup_theme(){

		$translate_locale 	=	get_template_directory_uri(). '/languages'; // Translation files location

		load_theme_textdomain( 'cmb2theme', $translate_locale ); // Loading translation files

		add_theme_support( 'menus' ); // Theme support for menus
		add_theme_support( 'html5' ); // Theme support for html5 code
		add_theme_support( 'automatic-feed-links' ); // Theme support for RSS feed
		add_theme_support( 'custom-logo' ); // Theme support for custom logos
		add_theme_support( 'title-tag' ); // Theme support for site title na tagline
		add_theme_support( 'widgets' ); // Theme support for widgets
		add_theme_support( 'post-thumbnails' ); // Theme support for featured image
		remove_theme_support( 'widgets-block-editor' ); // Remove Widget Block Editor
		add_theme_support( 'woocommerce' ); // Support woocommerce

		register_nav_menu( 'primary', esc_html__( 'Primary Menu', 'cmb2theme' ) ); // Registering Header Main Menu
		register_nav_menu( 'secondary', esc_html__( 'Top Bar Menu', 'cmb2theme' ) ); // Registering Header Top Bar Menu
		register_nav_menu( 'footer', esc_html__( 'Footer Menu', 'cmb2theme' ) ); // Registering Footer Menu

	}

?>