<?php 

/**
 *This is for nav menu walker. Where using our own classes, ids, attributes for sub menus. Nav walker only works on Sub menu.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/classes/walker_nav_menu/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

	Class DT_NAV_WALKER extends Walker_Nav_Menu{

		public function start_lvl(&$output, $depth = 0, $args = []){ // <ul> Start

			$output 		.=		'<ul class="navi-level-2" >';

		}

		public function start_el(&$output, $item, $depth = 0, $args =[], $id =0){ // <li> start

		$classes   = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;

		/**
		 * Filters the arguments for a single nav menu item.
		 *
		 * @since 4.4.0
		 *
		 * @param stdClass $args  An object of wp_nav_menu() arguments.
		 * @param WP_Post  $item  Menu item data object.
		 * @param int      $depth Depth of menu item. Used for padding.
		 */
		$args = apply_filters( 'nav_menu_item_args', $args, $item, $depth );

		/**
		 * Filters the CSS classes applied to a menu item's list item element.
		 *
		 * @since 3.0.0
		 * @since 4.1.0 The `$depth` parameter was added.
		 *
		 * @param string[] $classes Array of the CSS classes that are applied to the menu item's `<li>` element.
		 * @param WP_Post  $item    The current menu item.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 */
		$class_names = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		/**
		 * Filters the ID applied to a menu item's list item element.
		 *
		 * @since 3.0.1
		 * @since 4.1.0 The `$depth` parameter was added.
		 *
		 * @param string   $menu_id The ID that is applied to the menu item's `<li>` element.
		 * @param WP_Post  $item    The current menu item.
		 * @param stdClass $args    An object of wp_nav_menu() arguments.
		 * @param int      $depth   Depth of menu item. Used for padding.
		 */
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args, $depth );
		$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

			$output 		.=		'<li' .$id .$class_names. '>';
			$output 		.=		$args->before;
			$output			.=		'<a href="' .$item->url. '" >';
			$output			.=		$args->link_before .$item->title. $args->link_after;
			$output			.=		'</a>';
			$output 		.=		$args->after;

		}

		public function end_el(&$output, $item, $depth = 0, $args =[], $id =0){ // <li> Ends

			$output 		.=		'</li>';

		}

		public function end_lvl(&$output, $depth = 0, $args = []){ // <ul> ends

			$output 		.=		'</ul>';

		}

	}

 ?>