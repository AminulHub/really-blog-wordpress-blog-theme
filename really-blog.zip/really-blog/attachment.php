
<?php 

/**
*This template is for theme default attachment page. If there is no attachment template not there, then wordpress will use this template to show attachments.
* @link https://developer.wordpress.org/themes/template-files-section/attachment-template-files/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); 

?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" style="margin: 0;">
			<div id="list-blog" class="list-blog-warp">
				<?php 

				global $post;

				if (have_posts()) {
					while(have_posts()){
						the_post();
						?>
						<div class="blog-text">
							<h3 class="hover-text-theme"><?php the_title(); ?></h3>
						</div>
						<?php							   											   								
						the_content();
						?>
						<a download style="margin-top: 20px;" href="<?php echo $post->guid; ?>"><?php esc_html_e( 'Direct Download', 'cmb2theme' ); ?></a>
						<?php	
						
					}
				}

				?>



			</div>


		</div>
	</div>
</section>
<!-- /Main Content -->



<?php get_footer(); ?>