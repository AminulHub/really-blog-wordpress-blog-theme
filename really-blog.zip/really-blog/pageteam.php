<?php 

get_header();

/**
* This is a custom page template for custom post type Team. Users can choose templates from wordpress page editor.
* Template Name: Team
* Template Post Type: page
* @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}


?>

<!-- Main Content -->
<section >
	<div class="container">
		<div class="row">
			<div class="team-warp-page team-4-col">

				<?php

				$protected 	=	get_post();

				$dt_team	=		new WP_Query([

					'post_type'			=>		'team',
					'posts_per_page'	=>		-1

				]);

				if (post_password_required($protected->ID)) {
					echo get_the_password_form();
				}else{

					if ($dt_team->have_posts()) {
						while ($dt_team->have_posts()) {
							$dt_team->the_post();
							?>

							<div class="col-md-3">
								<div class="team-item">
									<div class="team-item-img-container">
										<?php 

										if (has_post_thumbnail()) {
											?>
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium', [ 'Class'	=>	'img-responsive' ] ); ?></a>
											<?php
										}

										 ?>
										
										<div class="overlay-1 hover-border-theme">
											<a href="<?php the_permalink(); ?>">
												<i class="fa fa-link hover-border-theme "></i>
											</a>

											<a class="single-img-popup" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id() )); ?>"><i class="fa fa-expand hover-border-theme "></i></a>
										</div>
									</div>
									<a href="<?php the_permalink(); ?>"><h4 class="team-name hover-text-theme"><?php the_title(); ?></h4></a>
									<p class="team-job color-theme "><?php the_terms( get_the_ID(), 'skills', '', ', ','' ); ?></p>
									<p class="team-info "><?php the_excerpt(); ?></p>
									<div class="team-social-warp border-color-theme">
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_fb_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_tw_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_lnk_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<?php
						}

						wp_reset_postdata();

					}

				}

				?>


			</div>
		</div>
	</div>
</section>
<!-- /Main Content -->

<?php get_footer(); ?>