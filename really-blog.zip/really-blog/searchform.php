
<?php 

/**
* This is searchform template. Use get_search_form() to show this search form in any other template.
* @link https://developer.wordpress.org/reference/functions/get_search_form/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

	$uniq_id	=	esc_attr(uniqid( 'search-form-' )); 

?>

<form role="search" class="form-inline search-form" action="<?php echo esc_url(home_url('/')); ?>" method="get">
	<div class="form-group">
		<input value="<?php esc_attr(the_search_query()); ?>" name="s" class="form-control" id="widgetsearch <?php echo $uniq_id; ?>" placeholder="<?php esc_attr_e( 'Type & Search...', 'really-blog' ); ?>" type="search">
	</div>

	<button type="button" class="reset-btn hover-text-theme"><i class="fa fa-search"></i></button>

</form>