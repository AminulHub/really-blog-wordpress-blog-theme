$( function() { $( 'audio' ).audioPlayer(); } );

$(document).ready(function(){

	$(".navi-level-2 li").hover(function(){


		$(".navi-level-2 li ul").removeClass("navi-level-2");

	});

	$(".navi-level-2 li").hover(function(){


		$(".navi-level-2 li ul").addClass("navi-level-3");

	});

	$("#dt-cmnt-replies").click(function(){


		$("li.comment ul.children").toggle('slow');

	});



});