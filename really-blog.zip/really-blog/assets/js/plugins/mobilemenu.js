jQuery(document).ready(function( $ ) {
   $("#menu").mmenu({
      "extensions": [
      "pagedim-black",
      "theme-dark"
      ],
      "offCanvas": {
         "position": "right"
      },
      "counters": true,
      "navbars": [
      {
         "position": "top",
         "content": [

         ]
      },
      {
         "position": "top"
      },
      {
         "position": "bottom",
         "content": [

         ]
      }
      ]
   });
});