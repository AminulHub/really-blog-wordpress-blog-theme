<?php
/**
 * Index file
 *
 * @package Really Blog
 * @since Really Blog 1.0.0
 */

/* Silence is golden, and we agree. */
