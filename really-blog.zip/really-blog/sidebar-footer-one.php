<?php 

/**
* This is footer sidebar number one. Registered custom sidebar.
* @link https://developer.wordpress.org/themes/functionality/sidebars/
* @package Really Blog
* @since 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

if (is_active_sidebar('dt_footer_w_1')) {
	dynamic_sidebar('dt_footer_w_1');
	if ( !get_theme_mod( 'cm_fwid_social_icons', 'yes' )) {
		
	?>

	<ul class="footer-social-icons social social-1" style="float: none !important; margin-bottom: 30px; text-align: left; margin-top: 15px;">
		<?php 

		if (get_theme_mod( 'dt_top_fb_handle', 'your_handle' )) {
			?>

			<li><a href="https://facebook.com/<?php echo get_theme_mod('dt_top_fb_handle') ?>" class="color-theme hover-text-dark"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>

			<?php
		}

		?>
		<?php 

		if (get_theme_mod('dt_top_twitter_handle', 'your_handle')) {
			?>
			<li><a href="https://twitter.com/<?php echo get_theme_mod('dt_top_twitter_handle'); ?>" class="color-theme hover-text-dark"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			<?php
		}

		?>
		<?php 

		if (get_theme_mod('dt_top_insta_handle', 'your_handle')) {
			?>
			<li><a href="https://instagram.com/<?php echo get_theme_mod('dt_top_insta_handle'); ?>" class="color-theme hover-text-dark"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
			<?php
		}

		?>
		<?php 

		if (get_theme_mod('dt_top_tumb_handle', 'your_handle')) {
			?>
			<li><a href="https://tumblr.com/<?php echo get_theme_mod('dt_top_tumb_handle'); ?>" class="color-theme hover-text-dark"><i class="fa fa-tumblr" aria-hidden="true"></i></a></li>
			<?php
		}

		?>
		<?php 

		if (get_theme_mod('dt_top_gplus_handle', 'your_handle')) {
			?>
			<li><a href="https://linkedin.com/<?php echo get_theme_mod('dt_top_gplus_handle'); ?>" class="color-theme hover-text-dark"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
			<?php
		}

		?>
	</ul>
	<?php
	}
}


?>