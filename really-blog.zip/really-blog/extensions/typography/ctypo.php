<?php
/**
  * This file is for custom typography in customizer. Included in functions.php
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

# Register our customizer panels, sections, settings, and controls.
add_action( 'customize_register', 'ctypo_customize_register', 15 );

# Load scripts and styles.
add_action( 'customize_controls_enqueue_scripts', 'ctypo_customize_controls_register_scripts' );

# Add custom styles to `<head>`.
add_action( 'wp_head', 'ctypo_print_styles' );

/**
 * Register customizer panels, sections, settings, and controls.
 *
 * @since  1.0.0
 * @access public
 * @param  object  $wp_customize
 * @return void
 */
function ctypo_customize_register( $wp_customize ) {

	// Load customizer typography control class.
	include(  'customize/control-typography.php' );

	// Register typography control JS template.
	$wp_customize->register_control_type( 'Customizer_Typo_Control_Typography' );

	/* === Testing === */

	// Add the typography panel.
	$wp_customize->add_panel( 'typography', array( 'priority' => 5, 'title' => esc_html__( 'Typography', 'cmb2theme' ) ) );

	// Add the `<p>` typography section.
	$wp_customize->add_section( 'body_typography', 
		array( 'panel' => 'typography', 'title' => esc_html__( 'Body', 'cmb2theme' ) )
	);


	// Add the `<p>` typography settings.
	// @todo Better sanitize_callback functions.
	$wp_customize->add_setting( 'p_font_family', array( 'default' => 'Arial',  'sanitize_callback' => 'sanitize_text_field') );
	$wp_customize->add_setting( 'p_font_weight', array( 'default' => '400',    'sanitize_callback' => 'absint' ) );

	// Add the `<h1>` typography settings.
	// @todo Better sanitize_callback functions.
	$wp_customize->add_setting( 'h1_font_family', array( 'default' => 'Georgia', 'sanitize_callback' => 'sanitize_text_field' ) );


	// Add the `<p>` typography control.
	$wp_customize->add_control(
		new Customizer_Typo_Control_Typography(
			$wp_customize,
			'p_typography',
			array(
				'label'       => esc_html__( 'Paragraph', 'cmb2theme' ),
				'section'     => 'body_typography',

				// Tie a setting (defined via `$wp_customize->add_setting()`) to the control.
				'settings'    => array(
					'family'      => 'p_font_family',
					'weight'      => 'p_font_weight',

				),

				// Pass custom labels. Use the setting key (above) for the specific label.
				'l10n'        => array(),
			)
		)
	);

	// Add the `<h1>` typography control.
	$wp_customize->add_control(
		new Customizer_Typo_Control_Typography(
			$wp_customize,
			'h_typography',
			array(
				'label'       => esc_html__( 'Headings', 'cmb2theme' ),
				'section'     => 'body_typography',

				// Tie a setting (defined via `$wp_customize->add_setting()`) to the control.
				'settings'    => array(
					'family'      => 'h1_font_family',
				),

				// Pass custom labels. Use the setting key (above) for the specific label.
				'l10n'        => array(),
			)
		)
	);


	/* === End Testing === */
}

/**
 * Register control scripts/styles.
 *
 * @since  1.0.0
 * @access public
 * @return void
 */
function ctypo_customize_controls_register_scripts() {

	$uri = get_theme_file_uri();

	wp_register_script( 'ctypo-customize-controls', esc_url( $uri . '/extensions/typography/js/customize-controls.js' ), array( 'customize-controls' ) );

	wp_register_style( 'ctypo-customize-controls', esc_url( $uri . '/extensions/typography/css/customize-controls.css' ) );
}

/**
 * Add custom body class to give some more weight to our styles.
 *
 * @since  1.0.0
 * @access public
 * @return void
 */
function ctypo_print_styles() {

	$style = $_p_style = $_h1_style =  '';

	$allowed_weights = array( 100, 300, 400, 500, 700, 900 );
	$allowed_styles  = array( 'normal', 'italic', 'oblique' );

	/* === <p> === */

	$p_family = get_theme_mod( 'p_font_family', '' );
	$p_weight = get_theme_mod( 'p_font_weight', '' );
	$p_style  = get_theme_mod( 'p_font_style',  '' );
	$p_size   = get_theme_mod( 'p_font_size',   '' );
	$p_line_h = get_theme_mod( 'p_line_height', '' );

	if ( $p_family )
		$_p_style .= sprintf( "font-family: '%s';", esc_attr( $p_family ) );

	if ( $p_weight )
		$_p_style .= sprintf( 'font-weight: %s;', in_array( absint( $p_weight ), $allowed_weights ) ? $p_weight : 400 );

	if ( $p_style )
		$_p_style .= sprintf( 'font-style: %s;', in_array( $p_style, $allowed_styles ) ? $p_style : 'normal' );

	if ( $p_size )
		$_p_style .= sprintf( 'font-size: %spx;', absint( $p_size ) );

	if ( $p_line_h )
		$_p_style .= sprintf( 'line-height: %spx;', absint( $p_line_h ) );

	if ( $_p_style )
		$_p_style = sprintf( 'body.ctypo p, a, span { %s }', $_p_style );

	/* === <h1> === */

	$h1_family = get_theme_mod( 'h1_font_family', '' );
	$h1_style  = get_theme_mod( 'h1_font_style',  '' );
	$h1_size   = get_theme_mod( 'h1_font_size',   '' );
	$h1_line_h = get_theme_mod( 'h1_line_height', '' );

	if ( $h1_family )
		$_h1_style .= sprintf( "font-family: '%s';", esc_attr( $h1_family ) );

	if ( $h1_style )
		$_h1_style .= sprintf( 'font-style: %s;', in_array( $h1_style, $allowed_styles ) ? $h1_style : 'normal' );

	if ( $h1_size )
		$_h1_style .= sprintf( 'font-size: %spx;', absint( $h1_size ) );

	if ( $h1_line_h )
		$_h1_style .= sprintf( 'line-height: %spx;', absint( $h1_line_h ) );

	if ( $_h1_style )
		$_h1_style = sprintf( 'body.ctypo h1, h2, h3, h4, h5, h6 { %s }', $_h1_style );


	/* === Output === */

	// Join the styles.
	$style = join( '', array( $_p_style, $_h1_style ) );

	// Output the styles.
	if ( $style ) {
		echo "\n" . '<style type="text/css" id="ctypo-css">' . $style . '</style>' . "\n";

		// Body class filter.
		add_filter( 'body_class', 'ctypo_body_class' );
	}
}

/**
 * Add custom body class to give some more weight to our styles.
 *
 * @since  1.0.0
 * @access public
 * @param  array  $classes
 * @return array
 */
function ctypo_body_class( $classes ) {
	return array_merge( $classes, array( 'ctypo' ) );
}
