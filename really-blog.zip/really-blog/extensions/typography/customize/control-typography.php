﻿<?php
/**
  * This is the main control file of the custom typgraphy. It is included in ctypo.php
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}
/**
 * Typography control class.
 *
 * @since  1.0.0
 * @access public
 */
class Customizer_Typo_Control_Typography extends WP_Customize_Control {

	/**
	 * The type of customize control being rendered.
	 *
	 * @since  1.0.0
	 * @access public
	 * @var    string
	 */
	public $type = 'typography';

	/**
	 * Array 
	 *
	 * @since  1.0.0
	 * @access public
	 * @var    string
	 */
	public $l10n = array();

	/**
	 * Set up our control.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @param  string  $id
	 * @param  array   $args
	 * @return void
	 */
	public function __construct( $manager, $id, $args = array() ) {

		// Let the parent class do its thing.
		parent::__construct( $manager, $id, $args );

		// Make sure we have labels.
		$this->l10n = wp_parse_args(
			$this->l10n,
			array(
				'family'      => esc_html__( 'Font Family', 'cmb2theme' ),
				'size'        => esc_html__( 'Font Size',   'cmb2theme' ),
				'weight'      => esc_html__( 'Font Weight', 'cmb2theme' ),
				'style'       => esc_html__( 'Font Style',  'cmb2theme' ),
				'line_height' => esc_html__( 'Line Height', 'cmb2theme' ),
			)
		);
	}

	/**
	 * Enqueue scripts/styles.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue() {
		wp_enqueue_script( 'ctypo-customize-controls' );
		wp_enqueue_style(  'ctypo-customize-controls' );
	}

	/**
	 * Add custom parameters to pass to the JS via JSON.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function to_json() {
		parent::to_json();

		// Loop through each of the settings and set up the data for it.
		foreach ( $this->settings as $setting_key => $setting_id ) {

			$this->json[ $setting_key ] = array(
				'link'  => $this->get_link( $setting_key ),
				'value' => $this->value( $setting_key ),
				'label' => isset( $this->l10n[ $setting_key ] ) ? $this->l10n[ $setting_key ] : ''
			);

			if ( 'family' === $setting_key )
				$this->json[ $setting_key ]['choices'] = $this->get_font_families();

			elseif ( 'weight' === $setting_key )
				$this->json[ $setting_key ]['choices'] = $this->get_font_weight_choices();

			elseif ( 'style' === $setting_key )
				$this->json[ $setting_key ]['choices'] = $this->get_font_style_choices();
		}
	}

	/**
	 * Underscore JS template to handle the control's output.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function content_template() { ?>

		<# if ( data.label ) { #>
			<span class="customize-control-title">{{ data.label }}</span>
		<# } #>

		<# if ( data.description ) { #>
			<span class="description customize-control-description">{{{ data.description }}}</span>
		<# } #>

		<ul>

		<# if ( data.family && data.family.choices ) { #>

			<li class="typography-font-family">

				<# if ( data.family.label ) { #>
					<span class="customize-control-title">{{ data.family.label }}</span>
				<# } #>

				<select {{{ data.family.link }}}>

					<# _.each( data.family.choices, function( label, choice ) { #>
						<option value="{{ choice }}" <# if ( choice === data.family.value ) { #> selected="selected" <# } #>>{{ label }}</option>
					<# } ) #>

				</select>
			</li>
		<# } #>

		<# if ( data.weight && data.weight.choices ) { #>

			<li class="typography-font-weight">

				<# if ( data.weight.label ) { #>
					<span class="customize-control-title">{{ data.weight.label }}</span>
				<# } #>

				<select {{{ data.weight.link }}}>

					<# _.each( data.weight.choices, function( label, choice ) { #>

						<option value="{{ choice }}" <# if ( choice === data.weight.value ) { #> selected="selected" <# } #>>{{ label }}</option>

					<# } ) #>

				</select>
			</li>
		<# } #>

		<# if ( data.style && data.style.choices ) { #>

			<li class="typography-font-style">

				<# if ( data.style.label ) { #>
					<span class="customize-control-title">{{ data.style.label }}</span>
				<# } #>

				<select {{{ data.style.link }}}>

					<# _.each( data.style.choices, function( label, choice ) { #>

						<option value="{{ choice }}" <# if ( choice === data.style.value ) { #> selected="selected" <# } #>>{{ label }}</option>

					<# } ) #>

				</select>
			</li>
		<# } #>

		<# if ( data.size ) { #>

			<li class="typography-font-size">

				<# if ( data.size.label ) { #>
					<span class="customize-control-title">{{ data.size.label }} (px)</span>
				<# } #>

				<input type="number" min="1" {{{ data.size.link }}} value="{{ data.size.value }}" />

			</li>
		<# } #>

		<# if ( data.line_height ) { #>

			<li class="typography-line-height">

				<# if ( data.line_height.label ) { #>
					<span class="customize-control-title">{{ data.line_height.label }} (px)</span>
				<# } #>

				<input type="number" min="1" {{{ data.line_height.link }}} value="{{ data.line_height.value }}" />

			</li>
		<# } #>

		</ul>
	<?php }

	/**
	 * Returns the available fonts.  Fonts should have available weights, styles, and subsets.
	 *
	 * @todo Integrate with Google fonts.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	public function get_fonts() { return array(); }

	/**
	 * Returns the available font families.
	 *
	 * @todo Pull families from `get_fonts()`.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	function get_font_families() {

		return array(
			'Arial'      			=> 	'Arial',
			'Arvo'      			=> 	'Arvo',
			'Cabin'      			=> 	'Cabin',
			'Crimson Text'      	=> 	'Crimson Text',
			'Dosis'      			=> 	'Dosis',
			'EB Garamond'      		=> 	'EB Garamond',
			'Fira Sans'      		=> 	'Fira Sans',
			'Georgia'    			=> 	'Georgia',
			'IBM Plex Serif'		=>	'IBM Plex Serif',
			'Inter'					=>	'Inter',
			'Lato'					=>	'Lato',
			'Lora'					=>	'Lora',
			'Libre Baskerville'		=>	'Libre Baskerville',
			'Merriweather'			=>	'Merriweather',
			'Montserrat'			=>	'Montserrat',
			'Noto Sans'				=>	'Noto Sans',
			'Nunito'				=>	'Nunito',
			'Nunito Sans'			=>	'Nunito Sans',
			'Open Sans'				=>	'Open Sans',
			'Open Sans Condensed'	=>	'Open Sans Condensed',
			'Oswald'				=>	'Oswald',
			'Oxygen'				=>	'Oxygen',
			'Playfair Display'		=>	'Playfair Display',
			'Poppins'				=>	'Poppins',
			'PT Sans'				=>	'PT Sans',
			'PT Serif'				=>	'PT Serif',
			'Quicksand'				=>	'Quicksand',
			'Raleway'				=>	'Raleway',
			'Roboto'				=>	'Roboto',
			'Roboto Condensed'		=>	'Roboto Condensed',
			'Roboto Mono'			=>	'Roboto Mono',
			'Roboto Slab'			=>	'Roboto Slab',
			'Slabo 27px'			=>	'Slabo 27px',
			'Source Sans Pro'		=>	'Source Sans Pro',
			'Source Serif Pro'		=>	'Source Serif Pro',
			'Titillium Web'			=>	'Titillium Web',
			'Ubuntu'				=>	'Ubuntu',
			'Work Sans'				=>	'Work Sans',
			'Zilla Slab'			=>	'Zilla Slab',
		);
	}

	/**
	 * Returns the available font weights.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	public function get_font_weight_choices() {

		return array(
			'100' => esc_html__( 'Thin',       'cmb2theme' ),
			'300' => esc_html__( 'Light',      'cmb2theme' ),
			'400' => esc_html__( 'Normal',     'cmb2theme' ),
			'500' => esc_html__( 'Medium',     'cmb2theme' ),
			'700' => esc_html__( 'Bold',       'cmb2theme' ),
			'900' => esc_html__( 'Ultra Bold', 'cmb2theme' ),
		);
	}

	/**
	 * Returns the available font styles.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	public function get_font_style_choices() {

		return array(
			'normal'  => esc_html__( 'Normal', 'cmb2theme' ),
			'italic'  => esc_html__( 'Italic', 'cmb2theme' ),
			'oblique' => esc_html__( 'Oblique', 'cmb2theme' )
		);
	}
}
