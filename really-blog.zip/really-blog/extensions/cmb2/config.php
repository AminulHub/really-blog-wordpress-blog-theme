<?php 

/**
  * This file is for use CMB2 custom fields in your theme. Here all the custom meta box, fields setup added. This file Included in theme functions.php.
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}


function cmb2_setup(){


	// Users Skills Field //
	$new_box_user =	new_cmb2_box( [

		'title'				=>		esc_html__( 'User Skills', 'cmb2theme' ),
		'id'				=>		'dt_user_box',
		'object_types'		=>		array( 'user' )	

	] );

	$new_box_user->add_field([

		'name'				=>		esc_html__( 'Skills. Separate by comma or space', 'cmb2theme'),
		'id'				=>		'dt_user_upload',
		'type'				=>		'text'

	]);


	// Single Project Fields //
	$project_box_one	=	new_cmb2_box( [

		'title'			=>		esc_html__( 'Project Details', 'cmb2theme' ),
		'id'			=>		'dt_project_details',
		'object_types'	=>		array( 'projects' )

	] );

	$project_box_one->add_field( [

		'name'			=>		esc_html__( 'Project Slider Images', 'cmb2theme'),
		'id'			=>		'dt_pro_img',
		'type'			=>		'file_list',

	] );

	$project_box_one->add_field( [

		'name'			=>		esc_html__( 'Agency Name', 'cmb2theme' ),
		'id'			=>		'dt_pro_ag_name',
		'type'			=>		'text_medium'

	] );

	$project_box_one->add_field( [

		'name'			=>		esc_html__( 'Client Name', 'cmb2theme' ),
		'id'			=>		'dt_pro_cl_name',
		'type'			=>		'text_medium'

	] );

	$project_box_one->add_field( [

		'name'			=>		esc_html__( 'Project Date', 'cmb2theme' ),
		'id'			=>		'dt_pro_dt',
		'type'			=>		'text_date',
		'date_format'	=>		'M j,  Y'

	] );

	$project_box_one->add_field( [

		'name'			=>		esc_html__( 'Link For Launch Button', 'cmb2theme' ),
		'id'			=>		'dt_pro_launch_url',
		'type'			=>		'text_url'

	] );



	// Team Member Details Fields //
	$dt_team_box	=	new_cmb2_box([

		'title'			=>		__( '<div style="font-size: 20px; font-weight: bold;">Personal Information</div>', 'cmb2theme' ),
		'id'			=>		'dt_team_box',
		'object_types'	=>	array( 'team' )

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Name', 'cmb2theme' ),
		'id'		=>		'dt_member_name',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Job', 'cmb2theme' ),
		'id'		=>		'dt_member_job',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Age', 'cmb2theme' ),
		'id'		=>		'dt_member_age',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Phone Number', 'cmb2theme' ),
		'id'		=>		'dt_member_phone',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Email Address', 'cmb2theme' ),
		'id'		=>		'dt_member_email',
		'type'		=>		'text_email'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Address', 'cmb2theme' ),
		'id'		=>		'dt_member_address',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Projects Counts', 'cmb2theme' ),
		'id'		=>		'dt_member_total_pro',
		'type'		=>		'radio_inline',
		'options'	=>		[

			'show'		=>		esc_html__( 'Show', 'cmb2theme' ),
			'hide'		=>		esc_html__( 'Hide', 'cmb2theme' )

		],
		'default'		=>		'show'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Total Projects Finished', 'cmb2theme' ),
		'id'		=>		'dt_member_finished',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Happy Clients', 'cmb2theme' ),
		'id'		=>		'dt_member_client',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Awards', 'cmb2theme' ),
		'id'		=>		'dt_member_award',
		'type'		=>		'text_medium'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'Show Skills', 'cmb2theme' ),
		'id'		=>		'dt_member_skills_show',
		'type'		=>		'radio_inline',
		'options'	=>		[

			'show'	=>		esc_html__( 'Show', 'cmb2theme' ),
			'hide'	=>		esc_html__( 'Hide', 'cmb2theme' ) 

		],
		'default'	=>		'show'

	]);

	$dt_team_box->add_field([

		'name'		=>		esc_html__( 'About Skills', 'cmb2theme' ),
		'id'		=>		'dt_member_skills',
		'type'		=>		'textarea'

	]);


	// Team Social Urls
	$dt_team_handles	=	new_cmb2_box([

		'title'			=>		__( '<div style="font-size: 20px; font-weight: bold;">Follow Me</div>', 'cmb2theme' ),
		'id'			=>		'dt_social_handles',
		'object_types'	=>	array( 'team' )

	]);

	$dt_team_handles->add_field([

		'name'			=>		esc_html__( 'Facebook', 'cmb2theme' ),
		'id'			=>		'dt_fb_cmb_handle',
		'type'			=>		'text_url'

	]);

	$dt_team_handles->add_field([

		'name'			=>		esc_html__( 'Twitter', 'cmb2theme' ),
		'id'			=>		'dt_tw_cmb_handle',
		'type'			=>		'text_url'

	]);

	$dt_team_handles->add_field([

		'name'			=>		esc_html__( 'Linkedin', 'cmb2theme' ),
		'id'			=>		'dt_lnk_cmb_handle',
		'type'			=>		'text_url'

	]);

	$dt_team_handles->add_field([

		'name'			=>		esc_html__( 'Tumblr', 'cmb2theme' ),
		'id'			=>		'dt_tmb_cmb_handle',
		'type'			=>		'text_url'

	]);

	$dt_team_handles->add_field([

		'name'			=>		esc_html__( 'Instagram', 'cmb2theme' ),
		'id'			=>		'dt_gplus_cmb_handle',
		'type'			=>		'text_url'

	]);


	// Team Member Contact Email Field For From //
	$dt_team_to_mail	=	new_cmb2_box([

		'title'			=>		__( '<div style="font-size: 20px; font-weight: bold;">Your Contact Form</div>', 'cmb2theme' ),
		'id'			=>		'dt_to_team_mail',
		'object_types'	=>		array( 'team' )

	]);

	$dt_team_to_mail->add_field([

		'name'			=>		esc_html__( 'To Mail Address', 'cmb2theme' ),
		'id'			=>		'dt_to_mail',
		'type'			=>		'text_email'

	]);



	//Group Fields For Team Skills & Progressh Bar


	$group_field_id = $dt_team_box->add_field( array(
		'id'          => 'wiki_test_repeat_group',
		'type'        => 'group',
		'description' => __( '<div style="font-size: 20px; font-weight: bold;">Add Your Skills</div>', 'cmb2theme' ),
    // 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
        'group_title'       => esc_html__( 'Entry {#}', 'cmb2theme' ), // since version 1.1.4, {#} gets replaced by row number
        'add_button'        => esc_html__( 'Add Another Skill', 'cmb2theme' ),
        'remove_button'     => esc_html__( 'Remove Skill', 'cmb2theme' ),
        'sortable'          => true,
        // 'closed'         => true, // true to have the groups closed by default
        // 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
    ),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.

	$dt_team_box->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Skill Name', 'cmb2theme' ),
		'id'   => 'image_caption',
		'type' => 'text',
	) );

	$dt_team_box->add_group_field( $group_field_id, array(
		'name' => esc_html__( 'Progress Bar(%)', 'cmb2theme' ),
		'id'   => 'title',
		'type' => 'text',
    // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );



	//Team Skills & Progress Bar Ends //



	// Post Type Video In Post Editor - Conditonal Field //
	$cmb_post_video	=	new_cmb2_box([

		'title'			=>		esc_html__( 'Choose Post Type', 'cmb2theme' ),
		'id'			=>		'dt_test_con',
		'object_types'	=>		array('post')

	]);


	$cmb_post_video->add_field( array(
		'name'             => esc_html__( 'Post Type', 'cmb2theme' ),
		'id'               => 'dt_post_video',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'video'   => esc_html__( 'Video', 'cmb2theme' ),
			'image'   => esc_html__( 'Image', 'cmb2theme' )
		),
	) );

	$cmb_post_video->add_field([

		'name'				=>		esc_html__( 'Post Video', 'cmb2theme' ),
		'desc'				=>		esc_html__( 'Upload Your Video URL Here. Use Featured Image for video poster.', 'cmb2theme' ),
		'id'				=>		'dt_video_upload',
		'type'				=>		'oembed',
		'attributes'		=>		array(

			'required'					=>		true,
			'data-conditional-id'		=>		'dt_post_video',
			'data-conditional-value'	=>		'video'

		)

	]);


}

add_action( 'cmb2_admin_init', 'cmb2_setup' );

?>