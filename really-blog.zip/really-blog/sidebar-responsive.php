<?php 

/**
* This sidebar template is only for mobile version.
* @link https://developer.wordpress.org/themes/functionality/sidebars/
* @package Really Blog
* @since 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

 ?>

	<div id="sidebar" class="main-sidebar">
		<?php 

		if (is_active_sidebar('dt_right_sbar')) {
			dynamic_sidebar('dt_right_sbar');
		}

		?>
	</div>
