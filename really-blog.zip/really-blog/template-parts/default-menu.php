<?php 
	
/**
 *This is for default menu link for Main Header Menu. When the theme will be installed, then this will show untill any menu is setup for main header menu. This file included in functions.php with get_template_part() function in the default menu function 
  *
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @link        https://developer.wordpress.org/reference/functions/get_template_part/
 * @since       Really Blog 1.0.0
*/

 ?>

<ul class="cmb2-default-main-menu">                  
    <li><a href="<?php echo esc_url(admin_url('nav-menus.php')); ?>"><?php esc_html_e( 'Set Up Your Menu', 'cmb2theme' ); ?></a></li>
</ul>