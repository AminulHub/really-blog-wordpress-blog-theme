
<?php 

/**
*This template is for custom taxonomy archive page.
* @link https://developer.wordpress.org/themes/template-files-section/taxonomy-templates/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header('tx'); 

?>

			   	<!-- Main Content -->
			   	<section id="main-content">
			   		<div class="container">
			   			<div class="row" style="margin: 0;">
			   					<div id="list-blog" class="list-blog-warp">
			   						<div class="archi-des">
			   							<?php the_archive_description(); ?>
			   						</div>
			   						<?php 

			   						

			   						if (have_posts()) {
			   							while(have_posts()){
			   								the_post();			   											   								
			   								?>
			   								<div class="col-md-3">
								<div class="team-item">
									<div class="team-item-img-container">
										<?php 

										if (has_post_thumbnail()) {
											?>
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium', [ 'Class'	=>	'img-responsive' ] ); ?></a>
											<?php
										}

										 ?>
										
										<div class="overlay-1 hover-border-theme">
											<a href="<?php the_permalink(); ?>">
												<i class="fa fa-link hover-border-theme "></i>
											</a>

											<a class="single-img-popup" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id() )); ?>"><i class="fa fa-expand hover-border-theme "></i></a>
										</div>
									</div>
									<a href="<?php the_permalink(); ?>"><h4 class="team-name hover-text-theme"><?php the_title(); ?></h4></a>
									<p class="team-job color-theme "><?php the_terms( get_the_ID(), 'skills', '', ', ','' ); ?></p>
									<p class="team-info "><?php the_excerpt(); ?></p>
									<div class="team-social-warp border-color-theme">
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_fb_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_tw_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
										<a href="<?php echo get_post_meta( get_the_ID(), 'dt_lnk_cmb_handle', true ); ?>" class="hover-text-theme"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
			   								<?php
			   							}

			   							?>

			   							
			   							<?php
			   						}

			   						 ?>
			   						


			   					</div>

			   					
			   				</div>
			   		</div>
			   	</section>
			   	<!-- /Main Content -->



<?php get_footer(); ?>