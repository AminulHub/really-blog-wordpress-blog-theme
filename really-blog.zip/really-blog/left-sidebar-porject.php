<?php 

get_header();

/**
* This is a custom post template for Left Sidebar Project(this is custom post type) single page where all the details of a project will be there. Users can choose templates from wordpress post editor.
* Template Name: Left Sidebar
* Template Post Type: projects
* @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
* @link https://developer.wordpress.org/plugins/post-types/registering-custom-post-types/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}


?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" style="margin: 0;">
			<div id="sidebar-for-res-hide" class="sidebar-page">
				<?php get_sidebar(); ?>
			</div>
			<div class="main-page">

				<?php 

				$protected_post	=	get_post();

				if (post_password_required($protected_post->ID)) {
					echo get_the_password_form();
				}else{
					if (have_posts()) {
						while (have_posts()) {
							the_post();
							?>
							<div id="single-portfolio" class="single-portfolio-warp">
								<div class="item-blog portfolio-gallery-feature-img">
									<div class="portfolio-feature-warp">

										<a class="prev-portfolio-image hover-border-theme hover-text-theme"></a>
										<a class="next-portfolio-image hover-border-theme hover-text-theme"></a>

										<div class="gallery-portfolio-post-warp">
											<div id="owl-gallery-portfolio-post" class="owl-carousel owl-theme owl-gallery-portfolio-post ">
												<?php 

												$meta = get_post_meta(get_the_ID(), 'dt_pro_img', true);

												if (!empty($meta)) {
													foreach ($meta as $pro_images) {
													?>													
														<div class="item">
														<img src="<?php echo esc_url($pro_images); ?>" class="img-responsive" alt="Image">
													</div>
													
													<?php
												}
												}

												

												 ?>
											</div>
										</div>
									</div>
								</div>
								<div class="portfolio-feature-content">
									<div class="porfolio-info-col col-description">
										<h3><?php esc_html_e( 'Project Description', 'cmb2theme' ); ?></h3>
										<?php the_content(); ?>

										<?php 

										if (get_theme_mod('dt_pro_show','yes')) {
											?>
											<a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_pro_launch_url', true )); ?>" class="ot-btn btn-main-color btn-rounded"><?php esc_html_e( 'LAUCH THE PROJECT', 'cmb2theme' ); ?><i class="fa fa-share-square-o" aria-hidden="true"></i></a>
											<?php
										}

										 ?>
										
									</div>

									<div class="porfolio-info-col col-detail">
										<h3><?php esc_html_e( 'Project Details', 'cmb2theme' ); ?></h3>
										<p><span><?php esc_html_e( 'Agency:', 'cmb2theme' ); ?></span><?php echo get_post_meta(get_the_ID(), 'dt_pro_ag_name', true); ?></p>
										<p><span><?php esc_html_e( 'Client:', 'cmb2theme' ); ?></span><?php echo get_post_meta(get_the_ID(), 'dt_pro_cl_name', true); ?></p>
										<p><span><?php esc_html_e( 'Date:', 'cmb2theme' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_pro_dt', true ); ?></p>

									</div>

									<div class="porfolio-info-col col-skill">
										<h3><?php esc_html_e( 'Used Skills', 'cmb2theme' ); ?></h3>
										<?php 

											global $post;

											$project_term	=	get_the_terms( $post->ID, 'proskills' );

											foreach ($project_term as $pro_s_term) {
												?>
												<p><i class="fa fa-check-circle color-theme" aria-hidden="true"></i><?php echo $pro_s_term->name; ?></p>
												<?php
											}

										?>
										
									</div>

								</div>
							</div>
							<!-- Relate Post -->
							<?php 

							if (get_theme_mod('dt_related_post_show','yes')) {
								?>
								<div class="relate-project" style="margin-top: 20px;">
								<h3 class="title-inline"><?php esc_html_e( 'Related Projects', 'cmb2theme' ); ?></h3>
								<div class="customNavigation customNavigation-1">
									<a class="btn-1 prev-relate-portfolio hover-border-theme hover-text-theme"><i class="fa fa-chevron-left"></i></a>
									<a class="btn-1 next-relate-portfolio hover-border-theme hover-text-theme"><i class="fa fa-chevron-right"></i></a>
								</div><!-- End owl button -->
								<div class="relate-portfolio-warp">
									<div id="owl-relate-portfolio" class="owl-carousel owl-theme owl-relate-portfolio ">
										<?php 

										$rp_porject		=	new WP_Query([


											'post_type'			=>		'projects',
											'category__in'		=>		wp_get_post_categories( $post->ID ),
											'posts_per_page'	=>		5,
											'post__not_in'		=>		[$post->ID]

										]);

										if ($rp_porject	->have_posts()) {
											while ($rp_porject	->have_posts()) {
												$rp_porject	->the_post();
												?>
											<div class="item">
											<div class="project-item">
												<div class="project-item-img-container">
													<?php 

													if (has_post_thumbnail()) {
														 the_post_thumbnail( 'medium', ['Class' => 'img-responsive'] );
													}

													 ?>
													
													<!-- Overlay -->
													<div class="overlay-1 ">
														<a href="<?php the_permalink(); ?>">
															<i class="fa fa-link hover-border-theme "></i>
														</a>

														<a class="single-img-popup" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id() )); ?>"><i class="fa fa-expand hover-border-theme "></i></a>
													</div>
													<!-- /overlay -->
												</div>
												<a href="#" ><h4 class="hover-text-theme"><?php the_title(); ?></h4></a>

												<p class="soft-grey-text hover-text-theme"><?php the_terms( $post->ID, 'proskills', '',', ', '' ) ?></p>
											</div>
										</div>
												<?php
											}

											wp_reset_postdata();
										}

										 ?>
										
									</div>
								</div>
							</div>
								<?php
							}

							 ?>
							
							<!-- /Relate Post -->
							<?php
						}
					}
				}

				?>

				

			</div>
			<!-- /Main Page -->
			<div id="sidebar-for-res-show" class="sidebar-page" style="padding-left: 0 !important;">
			<?php get_sidebar( 'responsive' ); ?>
		</div>
		</section>
		<!-- /Main Content -->

		

		<?php get_footer(); ?>