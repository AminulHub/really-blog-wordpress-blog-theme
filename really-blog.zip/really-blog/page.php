
<?php 

get_header();

/**
* This is default or main page template. If no other template is selected or not there, then wordpress will use this template to show a page.
* @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}


?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div style="margin: 0;" class="row" id="dt-logged-in">
			<?php 

			$protected_post	=		get_post();


				if (post_password_required($protected_post->ID)) {
				echo get_the_password_form();
			}else{

					while (have_posts()) {
						the_post();
						?>

						<div class="main-page">
							<div id="single-blog" class="single-blog-warp">
								<div class="item-blog">
									<?php 

									global $post;

									$author_id		=		$post->post_author;
									$author_url		=		esc_url(get_author_posts_url($author_id));

									if (has_post_thumbnail()) {
										?>

										<div class="blog-feature-warp">

											<?php the_post_thumbnail( 'Full', [ 'Class'	=>	'img-responsive' ] ); ?>

										</div>

										<?php
									}

									?>

									<div class="blog-feature-content single-feature-blog">
										<div class="blog-feature-content-inner">
											<div class="blog-text">
												<?php 

												the_content();

												$default	=		[

													'before'		=>		'<p class="text-center">'.esc_html__('Pages:', 'really-blog' ),
													'after'			=>		'</p>'

												];

												wp_link_pages($default);

												 ?>

												 

											</div>
										</div>
									</div>
								</div>
							</div>



							<!-- Comment Area -->
							<?php 

							if ( comments_open()  || get_comments_number() ) {
								comments_template();
							}

							?>
							<!-- /Comment Area -->
						</div>

						<?php
				}


			}

			
			?>
			
			<!-- /Main Page -->

		</div>
		<div class="sidebar-page">
			<?php get_sidebar(); ?>
		</div>
	</div>
</section>
<!-- /Main Content -->

<?php get_footer(); ?>