
<?php 

/**
* This is custom post type Team main single page where all the details of a team member will be shown.
* @link https://developer.wordpress.org/themes/template-files-section/post-template-files/
* @link https://developer.wordpress.org/plugins/post-types/registering-custom-post-types/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

get_header(); 

?>

<!-- Main Content -->
<?php 

    if(have_posts()){
	while (have_posts()) {
		the_post();
		?>
		<section >
			<div class="container">
				<div class="row" style="margin: 0;">
					<div class="single-team-warp">
						<div class="col-md-4" style="padding-left: 0; padding-right: 10px"> <!-- Padding left for child theme -->
							<div class="info-single-team">

								<div class="personal-avatar">
									<?php 

									if (has_post_thumbnail()) {
										the_post_thumbnail( 'medium', [ 'Class'	=>	'ig-responsive' ] );
									}

									?>
								</div>

								<h3 class="color-theme personal-title"><?php esc_html_e( 'PERSONAL INFORMATION', 'really-blog' ); ?></h3>

								<ul class="personal-information">
									<li><p><span><?php esc_html_e( 'Name: ', 'really-blog' ); ?></span> <?php echo get_post_meta( get_the_ID(), 'dt_member_name', true ); ?></p></li>
									<li><p><span><?php esc_html_e( 'Job: ', 'really-blog' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_member_job', true ); ?></p></li>
									<li><p><span><?php esc_html_e( 'Age: ', 'really-blog' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_member_age', true ); ?></p></li>
									<li><p><span><?php esc_html_e( 'Phone: ', 'really-blog' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_member_phone', true ); ?></p></li>
									<li><p><span><?php esc_html_e( 'Email: ', 'really-blog' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_member_email', true ); ?></p></li>
									<li><p><span><?php esc_html_e( 'Address: ', 'really-blog' ); ?></span><?php echo get_post_meta( get_the_ID(), 'dt_member_address', true ); ?></p></li>

								</ul>
								<h3 class="color-theme personal-title"><?php esc_html_e( 'Drop Me A Line', 'really-blog' ); ?></h3>
								<?php 

								if(isset($_POST['submit'])){
									    $to = get_post_meta( get_the_ID(), 'dt_to_mail', true ); // this is your Email address
									    $from = $_POST['email']; // this is the sender's Email address
									    $first_name = $_POST['name'];
									    $contact_u	=	esc_html_e( 'We will contact you shortly. ', 'really-blog' );
									    $subject = esc_html__( 'Message From', 'really-blog');
									    $write = esc_html__( 'wrote the following', 'really-blog');
									    $message = $first_name . " " . $write . "\n\n" . $_POST['message'];

									    $headers = esc_html__( 'From:', 'really-blog' ) . $from;
									    mail($to,$subject,$message,$headers);
									    esc_html_e( 'Mail Sent. Thank you ', 'really-blog' );
									    // You can also use header('Location: thank_you.php'); to redirect to another page.
									    }

								 ?>
								<form class="form-inline form-single-team" method="post" action="">
									<div class="form-team-single-warp">
										<div class="form-group">
											<input required name="name" class="form-control" id="exampleInputName2" placeholder="<?php esc_attr_e( 'Your Name...', 'really-blog' ); ?>" type="text">
										</div>
										<div class="form-group">
											<input required name="email" class="form-control" id="exampleInputEmail2" placeholder="<?php esc_attr_e( 'Your Email', 'really-blog' ); ?>" type="email">
										</div>

										<textarea required name="message" id="textarea" class="form-control" rows="3" required="required" placeholder="<?php esc_attr_e( 'Your Message', 'really-blog' ); ?>"></textarea>
										<button name="submit" type="submit" class="ot-btn btn-main-color btn-rounded bg-theme 
										text-up white-text"><?php esc_html_e( 'SEND MESSAGE', 'really-blog' ); ?><i class="fa fa-arrow-circle-right" aria-hidden="true"></i></button>
									</div>
								</form>
								<h3 class="color-theme personal-title"><?php esc_html_e( 'Follow Me On', 'really-blog' ); ?></h3>
								<ul class="social social-single-team">
									<?php 

									if (!empty(get_post_meta( get_the_ID(), 'dt_fb_cmb_handle', true ))) {
										?>
										<li><a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_fb_cmb_handle', true )); ?>" class=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
										<?php
									}

									 ?>
									 <?php
									if (!empty(get_post_meta( get_the_ID(), 'dt_tw_cmb_handle', true ))) {
										?>
									<li><a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_tw_cmb_handle', true )); ?>" class=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<?php
									}

									 ?>
									 <?php
									if (!empty(get_post_meta( get_the_ID(), 'dt_lnk_cmb_handle', true ))) {
										?>
									<li><a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_lnk_cmb_handle', true )); ?>" class=""><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
									<?php
									}

									 ?>
									 <?php
									if (!empty(get_post_meta( get_the_ID(), 'dt_tmb_cmb_handle', true ))) {
										?>
									<li><a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_tmb_cmb_handle', true )); ?>" class=""><i class="fa fa-tumblr" aria-hidden="true"></i></a></li>
									<?php
									}

									 ?>
									 <?php
									if (!empty(get_post_meta( get_the_ID(), 'dt_gplus_cmb_handle', true ))) {
										?>
									<li><a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_gplus_cmb_handle', true )); ?>" class=""><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
									<?php
									}

									 ?>
								</ul>
							</div>
						</div>
						
							<div class="col-md-8" style="padding-right: 0; padding-left: 0;"> <!-- Padding right 0 for child theme -->
							<div class="about-single-team">
								<div class="about-single-team-sum">
									<h3 class="color-theme personal-title"><?php single_post_title(); ?></h3>
									<?php the_content(); ?>
								</div>
							</div>
							<?php 

								$show_skills	=	get_post_meta(get_the_ID(), 'dt_member_skills_show', true);


								if ($show_skills == 'show') {
									?>
							<div class="owl-skill-warp">
								<h3 class="title-inline personal-title color-theme"><?php esc_html_e( 'SKILLS', 'really-blog' ); ?></h3>
								<div class="customNavigation customNavigation-1 customNavigation-skill">
									<a class="btn-1 prev-skill hover-border-theme hover-text-theme"><i class="fa fa-chevron-left"></i></a>
									<a class="btn-1 next-skill hover-border-theme hover-text-theme"><i class="fa fa-chevron-right"></i></a>
								</div><!-- End owl button -->

								<div class="skill-warp ">
									<?php echo get_post_meta(get_the_ID(), 'dt_member_skills', true); ?>
									<div id="owl-skill" class="owl-carousel owl-theme owl-skill ">
										<?php 

										$entries = get_post_meta( get_the_ID(), 'wiki_test_repeat_group', true );

											foreach ( (array) $entries as $key => $entry ) {

											    $img = $title = $desc = $caption = '';

											    if ( isset( $entry['title'] ) ) {
											        $title = esc_html( $entry['title'] );
											    }

											    $caption = isset( $entry['image_caption'] ) ? wpautop( $entry['image_caption'] ) : '';

											    ?>
											    <div class="item">
													<div style="" class="chart-v-item">
														<span class="percent-v update-v"></span>
														<div class="progress  vertical bottom progress-v ">
															<div class="progress-bar bar-chart bg-theme" role="progressbar" data-transitiongoal="<?php echo esc_attr($title); ?>"></div>
														</div>
														<span class="label-v"><?php echo $caption; ?></span>
													</div>
												</div>
											    <?php
											}
										?>


											

										
									</div>

									
								</div>
							</div>
						</div>
							<?php
						}

						 ?>
						
					</div>
				</div>
			</div>
		</section>

		<?php 

		

		$total_pro 		=	get_post_meta(get_the_ID(), 'dt_member_total_pro', true);

		if ($total_pro == 'show') {
			?>
			<section class="bg-light-grey">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="icon-box effect small clean">
							<div class="icon icon-dark">
								<a href="#"><i class="fa fa-file" aria-hidden="true"></i></a>
							</div>
							<h3><?php esc_html_e( 'Projects Finished', 'really-blog' ); ?></h3>
							<p><?php esc_html_e( 'I have Done', 'really-blog' ); ?></p>
							<span class="counter"><?php echo get_post_meta(get_the_ID(), 'dt_member_finished', true); ?></span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="icon-box effect small clean">
							<div class="icon icon-dark">
								<a href="#"><i class="fa fa-smile-o" aria-hidden="true"></i></a>
							</div>
							<h3><?php esc_html_e( 'Happy Clients', 'really-blog' ); ?></h3>
							<p><?php esc_html_e( 'I have Made', 'really-blog' ); ?></p>
							<span class="counter"><?php echo get_post_meta(get_the_ID(), 'dt_member_client', true); ?></span>
						</div>
					</div>
					<div class="col-md-4">
						<div class="icon-box effect small clean">
							<div class="icon icon-dark">
								<a href="#"><i class="fa fa-trophy" aria-hidden="true"></i></a>
							</div>
							<h3><?php esc_html_e( 'Award', 'really-blog' ); ?></h3>
							<p><?php esc_html_e( 'And I Obtained ', 'really-blog' ); ?></p>
							<span class="counter"><?php echo get_post_meta(get_the_ID(), 'dt_member_award', true); ?></span>
						</div>
					</div>
				</div>
			</div>
		</section>
			<?php
		}


		 ?>
		
		<?php
	}
}

?>
<?php get_footer(); ?>

