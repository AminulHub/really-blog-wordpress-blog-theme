
<?php 

/**
*This template is for 404 Error page. Not Found Page
* @link https://codex.wordpress.org/Creating_an_Error_404_Page
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); 

?>

<h2 style="text-align: center; margin: 30px 0;" ><?php esc_html_e( 'Page Not Found: 404', 'cmb2theme' );  ?></h2>



<?php get_footer(); ?>