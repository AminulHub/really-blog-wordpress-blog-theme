
<?php 

/**
*This template is for theme video archive page.
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package Really Blog
* @since 1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); 

?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" style="margin: 0;">
			<div id="list-blog" class="list-blog-warp">
				<?php 

				global $post;

				if (have_posts()) {
					while(have_posts()){
						the_post();
						?>
						<div class="blog-text">
							<h3 class="hover-text-theme"><?php the_title(); ?></h3>
						</div>
						<video class="video-archive" controls>
						  <source src="<?php echo $post->guid; ?>" style="margin-bottom: 12px; display: block;" type="video/mp4">
						  <source src="<?php echo $post->guid; ?>" style="margin-bottom: 12px; display: block;" type="video/ogg">
						</video>
						
						<?php
						the_content();
						?>
						<a download style="margin-top: 12px; display: block;" href="<?php echo esc_url($post->guid); ?>"><?php esc_html_e( 'Download Your Video', 'really-blog' ); ?></a>
						<?php									   								
						
						
						
						
					}
				}

				?>



			</div>


		</div>
	</div>
</section>
<!-- /Main Content -->



<?php get_footer(); ?>