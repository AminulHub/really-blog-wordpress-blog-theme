<?php 

/**
 * Default menus for Main Menu, Top Bar and Footer
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/themes/functionality/navigation-menus/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/



if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

 // Default Menu for Main Menu // The function 'wpex_default_menu' will be used in the value of 'fallback_cb' in 'wp_nav_menu' function.
 function wpex_default_menu() {
    get_template_part( 'template-parts/default-menu' );
}

 // Default Top Bar Menu // The function 'wpex_default_top_menu' will be used in the value of 'fallback_cb' in 'wp_nav_menu' function
 function wpex_default_top_menu() {
    get_template_part( 'template-parts/default-top-bar-menu' );
}

 // Default Footer Menu // The function 'wpex_default_fot_menu' will be used in the value of 'fallback_cb' in 'wp_nav_menu' function
 function wpex_default_fot_menu() {
    get_template_part( 'template-parts/default-footer-menu' );
}

 ?>