<?php 

/**
 *This template is for Video post excerpt. If any user choose post type 'video' in the editor, then this template will be used as excerpt template. It doesn't go with post formats as wordpress post formats don't work properly(not recommended). Post Type option created by CMB2 framework. Use this with get_template_part() in any other template in a loop in a condition. 
  *
 * @package     Really Blog
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @link        https://developer.wordpress.org/reference/functions/get_template_part/
 * @since       Really Blog 1.0.0
*/

?>

<div class="item-blog blog-video-popup">
	<div class="blog-feature-warp">
		<a href="<?php echo esc_url(get_post_meta( get_the_ID(), 'dt_video_upload', true )); ?>" class="popup-youtube overlay-btn-video">
			
		</a>
		<?php 
		if (has_post_thumbnail()) {
			the_post_thumbnail( 'medium', ['Class'	=>	'img-responsive'] );
		}
		?>
		

	</div>
	<div class="blog-feature-content">
		<div class="blog-feature-content-inner">
			<div class="blog-data">
				<div class="date-time bg-theme">
					<span class="date"><?php echo wp_kses_post(get_the_date('j')); ?></span>
					<span class="month"><?php echo wp_kses_post(get_the_date('M')); ?></span>
				</div>
				<div class="blog-type">
					<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/Icon/blogType-video.png" class="img-responsive" alt="Image">
				</div>
			</div>
			<div class="blog-text">
				<a href="<?php the_permalink(); ?>"><h3 class="hover-text-theme"><?php the_title(); ?></h3></a>
				<?php the_excerpt(); ?>
				<!-- <a href="<?php the_permalink(); ?>" class="readmore hover-text-theme">[read more]</a> -->
			</div>
		</div>
		<div class="blog-footer-2 border-color-theme">
			<ul>
				<li><?php esc_html_e( 'Posted by ', 'cmb2theme' ); ?><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>" class="hover-text-theme"><?php the_author(); ?></a></li>
				<li>On <a href="<?php the_permalink(); ?>" class="hover-text-theme"><?php the_category(' '); ?></a></li>
				<li>
					<a href="<?php the_permalink(); ?>" class="hover-text-theme">
						<?php 

						comments_number(
							'0'. esc_html__( ' Comment', 'cmb2theme' ), 
							'1'. esc_html__( ' Comment', 'cmb2theme' ), 
							'%'. esc_html__( ' Comments', 'cmb2theme' )
						); 

						?>
						
					</a>
				</li>
			</ul>
		</div>
	</div>
</div>
