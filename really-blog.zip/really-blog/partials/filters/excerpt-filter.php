<?php 

/**
 * Excerpt Filtering. How many words should be shown as excerpt if excerpt field is empty.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/excerpt_length/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function custom_excerpt_length( $length ) {
        return 10; // In excerpt only 10 words will be shown only excerpt filed is empty in the post. If anyone put content in the excerpt field manually, then those will be shown as excerpt.
    }
    add_filter( 'excerpt_length', 'custom_excerpt_length' );

 ?>