<?php 

/**
 * Chaning default excerpt sign to '...' by filter hook
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/excerpt_more/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function wpdocs_excerpt_more( $more ) {
    return '...'; // By default excerpt sign looks like this - [....]. We change it by filter hook.
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

 ?>