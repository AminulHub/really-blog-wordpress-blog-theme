<?php 

/**
 * Comment Reply Link Text Filtering
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/comment_reply_link/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

function wpb_comment_reply_text( $link ) {
$link = str_replace( 'Reply', 'REPLY THIS', $link ); // By Default reply button text is 'Reply' if we use 'wp_list_comments' function to show the comments list. Here we replaced with the word 'REPLY THIS' and then return the link.
return $link;
}
add_filter( 'comment_reply_link', 'wpb_comment_reply_text' );

 ?>