<?php 

/**
 * Filtering Comment Author Link.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/get_comment_author_link/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

add_filter( 'get_comment_author_link', function( $return, $author, $comment_id ){

    return $author = '<p style="margin-bottom:5px; font-weight: normal;">By '.$author.'</p>'; // By dafault in comment list, it shows Comment Author URL with it's URL when we use 'wp_list_comments' function. But we are filtering the Author URL. We don't want any URL to the commenter. So we return the $author within '<p>' tag where no anchor url will be used, only pure text.

}, 10, 3 );

 ?>