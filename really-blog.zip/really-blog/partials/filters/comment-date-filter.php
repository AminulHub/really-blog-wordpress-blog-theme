<?php 

/**
 * Comment Date Filter here.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/get_comment_date/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2022, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}

add_filter( 'get_comment_date', 'wpsites_change_comment_date_format' ); 
function wpsites_change_comment_date_format( $cmb2_cmntD ) {
    $cmb2_cmntD = date("j M, Y "); 
    return $cmb2_cmntD;
}

 ?>