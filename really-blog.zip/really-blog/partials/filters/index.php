<?php 

/**
* Index File
*
* @package Really Blog
* @since 1.0.0
*/

// Silence is golden, and we agree.

 ?>