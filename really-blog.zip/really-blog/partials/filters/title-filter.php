<?php 

/**
 * Filtering title. Only 5 words will be shown from the title.
  *
 * @package     Really Blog
 * @link     	https://developer.wordpress.org/reference/hooks/the_title/
 * @author      Aminul Sarkar
 * @copyright   Copyright (c) 2021, Really Blog
 * @link        https://aminulsarkar.com
 * @since       Really Blog 1.0.0
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // if accessed directly exit
}



// Filter Post Title of 'the_title' function. And limiting it to the 5 words. This doesn't work on Post Single page of this theme. There the full title will be shown as we used 'single_post_title' function there to get title.
add_filter( 'the_title', 'wpse_75691_trim_words' );

function wpse_75691_trim_words( $title )
{
    $cur_pt = get_post_type();
    if( 'post' == $cur_pt ) {   // limit to five words
     return wp_trim_words( $title, 5, '' );
    } else {
     return $title;
    }
}

 ?>