
<?php 

get_header();

/**
*This is a custom template for Full Width Page. Users can choose templates from wordpress page editor.
* Template Name: Full Width
* Template Post Type: page
* @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
* @package Really Blog
* @since 1.0.0
* 
*/

if ( !defined( 'ABSPATH' ) ) {
	exit; // exit if accessed directly
}

 ?>

<!-- Main Content -->
<section id="main-content">
	<div class="container">
		<div class="row" style="margin: 0;">
			<?php 

			$protected_post	=		get_post();

			// Checking if it set the password.
			if (post_password_required($protected_post->ID)) {
				
				echo get_the_password_form();

			}else{

					while (have_posts()) {
						the_post();
						?>
							<div id="single-blog" class="single-blog-warp">
								<div class="item-blog">
									<?php 

									global $post;

									$author_id		=		$post->post_author;
									$author_url		=		esc_url(get_author_posts_url($author_id));

									if (has_post_thumbnail()) {
										?>

										<div class="blog-feature-warp">

											<?php the_post_thumbnail( 'Full', [ 'Class'	=>	'img-responsive' ] ); ?>

										</div>

										<?php
									}

									?>

									<div class="blog-feature-content single-feature-blog">
										<div class="blog-feature-content-inner">
											<div class="blog-text">
												<?php 

												the_content();

												$default	=		[

													'before'		=>		'<p class="text-center">'.esc_html__('Pages:', 'cmb2theme' ),
													'after'			=>		'</p>'

												];

												wp_link_pages($default);

												 ?>

												 

											</div>
										</div>
									</div>
								</div>
							</div>



							<!-- Comment Area -->
								<?php 

							// Checking if comments are open or at least one comment there
							if ( comments_open() || get_comments_number() ) {

								comments_template();

							}

							?>
							
							<!-- /Comment Area -->

						<?php
				}


			}

			
			?>
			
			<!-- /Main Page -->

		</div>
	</div>
</section>
<!-- /Main Content -->

<?php get_footer(); ?>